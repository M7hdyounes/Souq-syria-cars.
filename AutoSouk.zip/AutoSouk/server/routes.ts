import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { 
  insertUserSchema, insertCarSchema, insertDealershipSchema, 
  insertMessageSchema, insertReviewSchema, insertComplaintSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket setup for real-time chat
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  const connections = new Map<string, WebSocket>();

  wss.on('connection', (ws, req) => {
    const userId = req.url?.split('userId=')[1];
    if (userId) {
      connections.set(userId, ws);
    }

    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        if (message.type === 'chat_message') {
          // Save message to storage
          const savedMessage = await storage.createMessage({
            senderId: message.senderId,
            receiverId: message.receiverId,
            carId: message.carId,
            content: message.content,
          });

          // Send to receiver if online
          const receiverWs = connections.get(message.receiverId);
          if (receiverWs && receiverWs.readyState === WebSocket.OPEN) {
            receiverWs.send(JSON.stringify({
              type: 'new_message',
              message: savedMessage,
            }));
          }
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      if (userId) {
        connections.delete(userId);
      }
    });
  });

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByEmail(userData.email);
      
      if (existingUser) {
        return res.status(400).json({ message: "البريد الإلكتروني مستخدم مسبقاً" });
      }

      const user = await storage.createUser(userData);
      res.json({ user: { ...user, password: undefined } });
    } catch (error) {
      res.status(400).json({ message: "خطأ في البيانات المدخلة" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      const user = await storage.getUserByEmail(email);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "البريد الإلكتروني أو كلمة المرور غير صحيحة" });
      }

      // Update last seen
      await storage.updateUser(user.id, { lastSeen: new Date() });

      res.json({ user: { ...user, password: undefined } });
    } catch (error) {
      res.status(500).json({ message: "خطأ في الخادم" });
    }
  });

  // Admin auth
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      const admin = await storage.getAdminByEmail(email);
      
      if (!admin || admin.password !== password) {
        return res.status(401).json({ message: "بيانات الدخول غير صحيحة" });
      }

      res.json({ admin: { ...admin, password: undefined } });
    } catch (error) {
      res.status(500).json({ message: "خطأ في الخادم" });
    }
  });

  // Cars routes
  app.get("/api/cars", async (req, res) => {
    try {
      const filters = req.query;
      const cars = await storage.getAllCars(filters);
      res.json(cars);
    } catch (error) {
      res.status(500).json({ message: "خطأ في جلب السيارات" });
    }
  });

  app.get("/api/cars/featured", async (req, res) => {
    try {
      const cars = await storage.getFeaturedCars();
      res.json(cars);
    } catch (error) {
      res.status(500).json({ message: "خطأ في جلب السيارات المميزة" });
    }
  });

  app.get("/api/cars/:id", async (req, res) => {
    try {
      const car = await storage.getCar(req.params.id);
      if (!car) {
        return res.status(404).json({ message: "السيارة غير موجودة" });
      }
      
      // Increment view count
      await storage.incrementCarViews(car.id);
      
      res.json(car);
    } catch (error) {
      res.status(500).json({ message: "خطأ في جلب تفاصيل السيارة" });
    }
  });

  app.post("/api/cars", async (req, res) => {
    try {
      const carData = insertCarSchema.parse(req.body);
      const { sellerId } = req.body;
      
      if (!sellerId) {
        return res.status(400).json({ message: "معرف البائع مطلوب" });
      }

      const car = await storage.createCar({ ...carData, sellerId });
      res.json(car);
    } catch (error) {
      res.status(400).json({ message: "خطأ في إضافة السيارة" });
    }
  });

  app.put("/api/cars/:id", async (req, res) => {
    try {
      const updates = req.body;
      const car = await storage.updateCar(req.params.id, updates);
      
      if (!car) {
        return res.status(404).json({ message: "السيارة غير موجودة" });
      }
      
      res.json(car);
    } catch (error) {
      res.status(500).json({ message: "خطأ في تحديث السيارة" });
    }
  });

  app.delete("/api/cars/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteCar(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "السيارة غير موجودة" });
      }
      res.json({ message: "تم حذف السيارة بنجاح" });
    } catch (error) {
      res.status(500).json({ message: "خطأ في حذف السيارة" });
    }
  });

  // User cars
  app.get("/api/users/:userId/cars", async (req, res) => {
    try {
      const cars = await storage.getCarsByUser(req.params.userId);
      res.json(cars);
    } catch (error) {
      res.status(500).json({ message: "خطأ في جلب سيارات المستخدم" });
    }
  });

  // Favorites
  app.post("/api/favorites", async (req, res) => {
    try {
      const { userId, carId } = req.body;
      const favorite = await storage.addFavorite(userId, carId);
      res.json(favorite);
    } catch (error) {
      res.status(500).json({ message: "خطأ في إضافة السيارة للمفضلة" });
    }
  });

  app.delete("/api/favorites", async (req, res) => {
    try {
      const { userId, carId } = req.body;
      const removed = await storage.removeFavorite(userId, carId);
      
      if (!removed) {
        return res.status(404).json({ message: "المفضلة غير موجودة" });
      }
      
      res.json({ message: "تم حذف السيارة من المفضلة" });
    } catch (error) {
      res.status(500).json({ message: "خطأ في حذف السيارة من المفضلة" });
    }
  });

  app.get("/api/users/:userId/favorites", async (req, res) => {
    try {
      const favorites = await storage.getUserFavorites(req.params.userId);
      res.json(favorites);
    } catch (error) {
      res.status(500).json({ message: "خطأ في جلب المفضلة" });
    }
  });

  // Dealerships
  app.get("/api/dealerships", async (req, res) => {
    try {
      const dealerships = await storage.getAllDealerships();
      res.json(dealerships);
    } catch (error) {
      res.status(500).json({ message: "خطأ في جلب المعارض" });
    }
  });

  app.get("/api/dealerships/featured", async (req, res) => {
    try {
      const dealerships = await storage.getFeaturedDealerships();
      res.json(dealerships);
    } catch (error) {
      res.status(500).json({ message: "خطأ في جلب المعارض المميزة" });
    }
  });

  app.get("/api/dealerships/:id", async (req, res) => {
    try {
      const dealership = await storage.getDealership(req.params.id);
      if (!dealership) {
        return res.status(404).json({ message: "المعرض غير موجود" });
      }
      res.json(dealership);
    } catch (error) {
      res.status(500).json({ message: "خطأ في جلب تفاصيل المعرض" });
    }
  });

  app.get("/api/dealerships/:id/cars", async (req, res) => {
    try {
      const cars = await storage.getCarsByDealership(req.params.id);
      res.json(cars);
    } catch (error) {
      res.status(500).json({ message: "خطأ في جلب سيارات المعرض" });
    }
  });

  app.post("/api/dealerships", async (req, res) => {
    try {
      const dealershipData = insertDealershipSchema.parse(req.body);
      const { ownerId } = req.body;
      
      if (!ownerId) {
        return res.status(400).json({ message: "معرف المالك مطلوب" });
      }

      const dealership = await storage.createDealership({ ...dealershipData, ownerId });
      res.json(dealership);
    } catch (error) {
      res.status(400).json({ message: "خطأ في إضافة المعرض" });
    }
  });

  // Messages
  app.get("/api/messages/:userId", async (req, res) => {
    try {
      const messages = await storage.getUserMessages(req.params.userId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "خطأ في جلب الرسائل" });
    }
  });

  app.get("/api/conversations/:userId1/:userId2", async (req, res) => {
    try {
      const { userId1, userId2 } = req.params;
      const { carId } = req.query;
      const messages = await storage.getConversation(userId1, userId2, carId as string);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "خطأ في جلب المحادثة" });
    }
  });

  app.post("/api/messages", async (req, res) => {
    try {
      const messageData = insertMessageSchema.parse(req.body);
      const { senderId } = req.body;
      
      if (!senderId) {
        return res.status(400).json({ message: "معرف المرسل مطلوب" });
      }

      const message = await storage.createMessage({ ...messageData, senderId });
      res.json(message);
    } catch (error) {
      res.status(400).json({ message: "خطأ في إرسال الرسالة" });
    }
  });

  // Reviews
  app.post("/api/reviews", async (req, res) => {
    try {
      const reviewData = insertReviewSchema.parse(req.body);
      const { reviewerId } = req.body;
      
      if (!reviewerId) {
        return res.status(400).json({ message: "معرف المقيم مطلوب" });
      }

      const review = await storage.createReview({ ...reviewData, reviewerId });
      res.json(review);
    } catch (error) {
      res.status(400).json({ message: "خطأ في إضافة التقييم" });
    }
  });

  app.get("/api/users/:userId/reviews", async (req, res) => {
    try {
      const reviews = await storage.getReviewsForUser(req.params.userId);
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ message: "خطأ في جلب التقييمات" });
    }
  });

  // Complaints
  app.post("/api/complaints", async (req, res) => {
    try {
      const complaintData = insertComplaintSchema.parse(req.body);
      const { userId } = req.body;
      
      if (!userId) {
        return res.status(400).json({ message: "معرف المستخدم مطلوب" });
      }

      const complaint = await storage.createComplaint({ ...complaintData, userId });
      res.json(complaint);
    } catch (error) {
      res.status(400).json({ message: "خطأ في إرسال الشكوى" });
    }
  });

  // Admin routes
  app.get("/api/admin/stats", async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "خطأ في جلب الإحصائيات" });
    }
  });

  app.get("/api/admin/complaints", async (req, res) => {
    try {
      const complaints = await storage.getAllComplaints();
      res.json(complaints);
    } catch (error) {
      res.status(500).json({ message: "خطأ في جلب الشكاوى" });
    }
  });

  app.put("/api/admin/complaints/:id", async (req, res) => {
    try {
      const updates = req.body;
      const complaint = await storage.updateComplaint(req.params.id, updates);
      
      if (!complaint) {
        return res.status(404).json({ message: "الشكوى غير موجودة" });
      }
      
      res.json(complaint);
    } catch (error) {
      res.status(500).json({ message: "خطأ في تحديث الشكوى" });
    }
  });

  app.get("/api/admin/cars", async (req, res) => {
    try {
      const cars = await storage.getAllCars();
      res.json(cars);
    } catch (error) {
      res.status(500).json({ message: "خطأ في جلب السيارات" });
    }
  });

  app.put("/api/admin/cars/:id/approve", async (req, res) => {
    try {
      const car = await storage.updateCar(req.params.id, { isApproved: true });
      
      if (!car) {
        return res.status(404).json({ message: "السيارة غير موجودة" });
      }
      
      res.json(car);
    } catch (error) {
      res.status(500).json({ message: "خطأ في الموافقة على السيارة" });
    }
  });

  return httpServer;
}
