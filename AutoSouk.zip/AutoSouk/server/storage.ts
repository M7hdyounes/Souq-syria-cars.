import { 
  type User, type InsertUser, type Car, type InsertCar, 
  type Dealership, type InsertDealership, type Message, type InsertMessage,
  type Review, type InsertReview, type Complaint, type InsertComplaint,
  type Admin, type InsertAdmin, type Favorite
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByPhone(phone: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  
  // Cars
  getCar(id: string): Promise<Car | undefined>;
  getCarsByUser(userId: string): Promise<Car[]>;
  getCarsByDealership(dealershipId: string): Promise<Car[]>;
  getAllCars(filters?: any): Promise<Car[]>;
  getFeaturedCars(): Promise<Car[]>;
  createCar(car: InsertCar & { sellerId: string }): Promise<Car>;
  updateCar(id: string, updates: Partial<Car>): Promise<Car | undefined>;
  deleteCar(id: string): Promise<boolean>;
  incrementCarViews(carId: string): Promise<void>;
  
  // Dealerships
  getDealership(id: string): Promise<Dealership | undefined>;
  getDealershipsByOwner(ownerId: string): Promise<Dealership[]>;
  getAllDealerships(): Promise<Dealership[]>;
  getFeaturedDealerships(): Promise<Dealership[]>;
  createDealership(dealership: InsertDealership & { ownerId: string }): Promise<Dealership>;
  updateDealership(id: string, updates: Partial<Dealership>): Promise<Dealership | undefined>;
  
  // Favorites
  addFavorite(userId: string, carId: string): Promise<Favorite>;
  removeFavorite(userId: string, carId: string): Promise<boolean>;
  getUserFavorites(userId: string): Promise<Car[]>;
  
  // Messages
  createMessage(message: InsertMessage & { senderId: string }): Promise<Message>;
  getConversation(userId1: string, userId2: string, carId?: string): Promise<Message[]>;
  getUserMessages(userId: string): Promise<Message[]>;
  markMessageAsRead(messageId: string): Promise<void>;
  
  // Reviews
  createReview(review: InsertReview & { reviewerId: string }): Promise<Review>;
  getReviewsForUser(userId: string): Promise<Review[]>;
  getReviewsForDealership(dealershipId: string): Promise<Review[]>;
  
  // Complaints
  createComplaint(complaint: InsertComplaint & { userId: string }): Promise<Complaint>;
  getAllComplaints(): Promise<Complaint[]>;
  updateComplaint(id: string, updates: Partial<Complaint>): Promise<Complaint | undefined>;
  
  // Admin
  getAdminByEmail(email: string): Promise<Admin | undefined>;
  createAdmin(admin: InsertAdmin): Promise<Admin>;
  
  // Analytics
  getStats(): Promise<any>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private cars: Map<string, Car> = new Map();
  private dealerships: Map<string, Dealership> = new Map();
  private favorites: Map<string, Favorite> = new Map();
  private messages: Map<string, Message> = new Map();
  private reviews: Map<string, Review> = new Map();
  private complaints: Map<string, Complaint> = new Map();
  private admins: Map<string, Admin> = new Map();

  constructor() {
    // Create default admin
    const adminId = randomUUID();
    this.admins.set(adminId, {
      id: adminId,
      email: "my3450589@gmail.com",
      password: "12345678mhd9",
      role: "admin",
      createdAt: new Date(),
    });
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.phone === phone);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      isEmailVerified: false,
      isPhoneVerified: false,
      rating: "0",
      reviewCount: 0,
      lastSeen: new Date(),
      preferences: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates, updatedAt: new Date() };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Cars
  async getCar(id: string): Promise<Car | undefined> {
    return this.cars.get(id);
  }

  async getCarsByUser(userId: string): Promise<Car[]> {
    return Array.from(this.cars.values()).filter(car => car.sellerId === userId);
  }

  async getCarsByDealership(dealershipId: string): Promise<Car[]> {
    return Array.from(this.cars.values()).filter(car => car.dealershipId === dealershipId);
  }

  async getAllCars(filters?: any): Promise<Car[]> {
    let cars = Array.from(this.cars.values()).filter(car => car.isApproved);
    
    if (filters) {
      if (filters.brand) cars = cars.filter(car => car.brand === filters.brand);
      if (filters.bodyType) cars = cars.filter(car => car.bodyType === filters.bodyType);
      if (filters.city) cars = cars.filter(car => car.city === filters.city);
      if (filters.minPrice) cars = cars.filter(car => parseFloat(car.price) >= filters.minPrice);
      if (filters.maxPrice) cars = cars.filter(car => parseFloat(car.price) <= filters.maxPrice);
    }
    
    return cars.sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async getFeaturedCars(): Promise<Car[]> {
    return Array.from(this.cars.values())
      .filter(car => car.isFeatured && car.isApproved)
      .slice(0, 6);
  }

  async createCar(carData: InsertCar & { sellerId: string }): Promise<Car> {
    const id = randomUUID();
    const car: Car = {
      ...carData,
      id,
      dealershipId: carData.dealershipId || null,
      mileage: carData.mileage || null,
      fuelType: carData.fuelType || null,
      transmission: carData.transmission || null,
      bodyType: carData.bodyType || null,
      color: carData.color || null,
      images: carData.images || null,
      interiorImages: carData.interiorImages || null,
      exteriorImages: carData.exteriorImages || null,
      features: carData.features || null,
      tireCondition: carData.tireCondition || null,
      batteryCondition: carData.batteryCondition || null,
      technicalReport: null,
      marketValue: null,
      negotiable: carData.negotiable ?? true,
      installmentAvailable: carData.installmentAvailable ?? false,
      tradeInAccepted: carData.tradeInAccepted ?? false,
      status: "active",
      isApproved: false,
      isFeatured: false,
      viewCount: 0,
      favoriteCount: 0,
      expiresAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.cars.set(id, car);
    return car;
  }

  async updateCar(id: string, updates: Partial<Car>): Promise<Car | undefined> {
    const car = this.cars.get(id);
    if (!car) return undefined;
    
    const updatedCar = { ...car, ...updates, updatedAt: new Date() };
    this.cars.set(id, updatedCar);
    return updatedCar;
  }

  async deleteCar(id: string): Promise<boolean> {
    return this.cars.delete(id);
  }

  async incrementCarViews(carId: string): Promise<void> {
    const car = this.cars.get(carId);
    if (car) {
      car.viewCount = (car.viewCount || 0) + 1;
      this.cars.set(carId, car);
    }
  }

  // Dealerships
  async getDealership(id: string): Promise<Dealership | undefined> {
    return this.dealerships.get(id);
  }

  async getDealershipsByOwner(ownerId: string): Promise<Dealership[]> {
    return Array.from(this.dealerships.values()).filter(d => d.ownerId === ownerId);
  }

  async getAllDealerships(): Promise<Dealership[]> {
    return Array.from(this.dealerships.values());
  }

  async getFeaturedDealerships(): Promise<Dealership[]> {
    return Array.from(this.dealerships.values())
      .filter(d => d.isVerified)
      .sort((a, b) => parseFloat(b.rating || "0") - parseFloat(a.rating || "0"))
      .slice(0, 4);
  }

  async createDealership(dealershipData: InsertDealership & { ownerId: string }): Promise<Dealership> {
    const id = randomUUID();
    const dealership: Dealership = {
      ...dealershipData,
      id,
      description: dealershipData.description || null,
      logo: dealershipData.logo || null,
      coverImage: dealershipData.coverImage || null,
      address: dealershipData.address || null,
      phone: dealershipData.phone || null,
      email: dealershipData.email || null,
      website: dealershipData.website || null,
      rating: "0",
      reviewCount: 0,
      isVerified: false,
      subscriptionPlan: "free",
      subscriptionExpiresAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.dealerships.set(id, dealership);
    return dealership;
  }

  async updateDealership(id: string, updates: Partial<Dealership>): Promise<Dealership | undefined> {
    const dealership = this.dealerships.get(id);
    if (!dealership) return undefined;
    
    const updatedDealership = { ...dealership, ...updates, updatedAt: new Date() };
    this.dealerships.set(id, updatedDealership);
    return updatedDealership;
  }

  // Favorites
  async addFavorite(userId: string, carId: string): Promise<Favorite> {
    const id = randomUUID();
    const favorite: Favorite = {
      id,
      userId,
      carId,
      createdAt: new Date(),
    };
    this.favorites.set(id, favorite);
    
    // Update car favorite count
    const car = this.cars.get(carId);
    if (car) {
      car.favoriteCount = (car.favoriteCount || 0) + 1;
      this.cars.set(carId, car);
    }
    
    return favorite;
  }

  async removeFavorite(userId: string, carId: string): Promise<boolean> {
    const favorite = Array.from(this.favorites.values())
      .find(f => f.userId === userId && f.carId === carId);
    
    if (!favorite) return false;
    
    this.favorites.delete(favorite.id);
    
    // Update car favorite count
    const car = this.cars.get(carId);
    if (car) {
      car.favoriteCount = Math.max(0, (car.favoriteCount || 0) - 1);
      this.cars.set(carId, car);
    }
    
    return true;
  }

  async getUserFavorites(userId: string): Promise<Car[]> {
    const userFavorites = Array.from(this.favorites.values())
      .filter(f => f.userId === userId);
    
    return userFavorites
      .map(f => this.cars.get(f.carId))
      .filter(car => car) as Car[];
  }

  // Messages
  async createMessage(messageData: InsertMessage & { senderId: string }): Promise<Message> {
    const id = randomUUID();
    const message: Message = {
      ...messageData,
      id,
      carId: messageData.carId || null,
      isRead: false,
      createdAt: new Date(),
    };
    this.messages.set(id, message);
    return message;
  }

  async getConversation(userId1: string, userId2: string, carId?: string): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(m => 
        ((m.senderId === userId1 && m.receiverId === userId2) ||
         (m.senderId === userId2 && m.receiverId === userId1)) &&
        (!carId || m.carId === carId)
      )
      .sort((a, b) => new Date(a.createdAt!).getTime() - new Date(b.createdAt!).getTime());
  }

  async getUserMessages(userId: string): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(m => m.senderId === userId || m.receiverId === userId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async markMessageAsRead(messageId: string): Promise<void> {
    const message = this.messages.get(messageId);
    if (message) {
      message.isRead = true;
      this.messages.set(messageId, message);
    }
  }

  // Reviews
  async createReview(reviewData: InsertReview & { reviewerId: string }): Promise<Review> {
    const id = randomUUID();
    const review: Review = {
      ...reviewData,
      id,
      carId: reviewData.carId || null,
      dealershipId: reviewData.dealershipId || null,
      comment: reviewData.comment || null,
      createdAt: new Date(),
    };
    this.reviews.set(id, review);
    return review;
  }

  async getReviewsForUser(userId: string): Promise<Review[]> {
    return Array.from(this.reviews.values()).filter(r => r.reviewedId === userId);
  }

  async getReviewsForDealership(dealershipId: string): Promise<Review[]> {
    return Array.from(this.reviews.values()).filter(r => r.dealershipId === dealershipId);
  }

  // Complaints
  async createComplaint(complaintData: InsertComplaint & { userId: string }): Promise<Complaint> {
    const id = randomUUID();
    const complaint: Complaint = {
      ...complaintData,
      id,
      status: "pending",
      response: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.complaints.set(id, complaint);
    return complaint;
  }

  async getAllComplaints(): Promise<Complaint[]> {
    return Array.from(this.complaints.values())
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async updateComplaint(id: string, updates: Partial<Complaint>): Promise<Complaint | undefined> {
    const complaint = this.complaints.get(id);
    if (!complaint) return undefined;
    
    const updatedComplaint = { ...complaint, ...updates, updatedAt: new Date() };
    this.complaints.set(id, updatedComplaint);
    return updatedComplaint;
  }

  // Admin
  async getAdminByEmail(email: string): Promise<Admin | undefined> {
    return Array.from(this.admins.values()).find(admin => admin.email === email);
  }

  async createAdmin(insertAdmin: InsertAdmin): Promise<Admin> {
    const id = randomUUID();
    const admin: Admin = {
      ...insertAdmin,
      id,
      createdAt: new Date(),
    };
    this.admins.set(id, admin);
    return admin;
  }

  // Analytics
  async getStats(): Promise<any> {
    return {
      totalCars: this.cars.size,
      totalUsers: this.users.size,
      totalDealerships: this.dealerships.size,
      pendingComplaints: Array.from(this.complaints.values()).filter(c => c.status === "pending").length,
      unapprovedCars: Array.from(this.cars.values()).filter(c => !c.isApproved).length,
    };
  }
}

export const storage = new MemStorage();
