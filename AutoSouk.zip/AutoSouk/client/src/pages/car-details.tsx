import { useState } from "react";
import { useRoute, Link } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/components/language-provider";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { motion } from "framer-motion";
import { 
  Heart, Share2, MessageCircle, Phone, MapPin, Calendar, 
  Gauge, Fuel, Settings, Palette, Star, Eye, ChevronLeft, 
  ChevronRight, Camera, Shield, TrendingUp, Clock, Car
} from "lucide-react";

export default function CarDetails() {
  const [, params] = useRoute("/cars/:id");
  const { user } = useAuth();
  const { t, language } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showContactDialog, setShowContactDialog] = useState(false);
  const [message, setMessage] = useState("");

  const carId = params?.id;

  // Fetch car details
  const { data: car, isLoading, error } = useQuery({
    queryKey: ['/api/cars', carId],
    queryFn: async () => {
      const response = await fetch(`/api/cars/${carId}`);
      if (!response.ok) throw new Error('Car not found');
      return response.json();
    },
    enabled: !!carId,
  });

  // Fetch similar cars
  const { data: similarCars = [] } = useQuery({
    queryKey: ['/api/cars', 'similar', car?.brand, car?.bodyType],
    queryFn: async () => {
      if (!car) return [];
      const response = await fetch(`/api/cars?brand=${car.brand}&bodyType=${car.bodyType}&limit=4`);
      if (!response.ok) return [];
      const allCars = await response.json();
      return allCars.filter((c: any) => c.id !== car.id).slice(0, 4);
    },
    enabled: !!car,
  });

  const favoriteMutation = useMutation({
    mutationFn: async () => {
      if (!user || !car) throw new Error("يجب تسجيل الدخول أولاً");
      return apiRequest("POST", "/api/favorites", { userId: user.id, carId: car.id });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cars'] });
      toast({
        title: "تمت الإضافة",
        description: "تم إضافة السيارة إلى المفضلة"
      });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      if (!user || !car) throw new Error("يجب تسجيل الدخول أولاً");
      return apiRequest("POST", "/api/messages", {
        senderId: user.id,
        receiverId: car.sellerId,
        carId: car.id,
        content
      });
    },
    onSuccess: () => {
      toast({
        title: "تم الإرسال",
        description: "تم إرسال رسالتك بنجاح"
      });
      setMessage("");
      setShowContactDialog(false);
    },
    onError: (error: any) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse">
            <div className="bg-gray-200 dark:bg-gray-700 rounded-2xl h-96 mb-8"></div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-4">
                <div className="bg-gray-200 dark:bg-gray-700 rounded h-8"></div>
                <div className="bg-gray-200 dark:bg-gray-700 rounded h-4"></div>
                <div className="bg-gray-200 dark:bg-gray-700 rounded h-32"></div>
              </div>
              <div className="space-y-4">
                <div className="bg-gray-200 dark:bg-gray-700 rounded h-64"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !car) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Card className="p-8 text-center max-w-md mx-4">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            {language === "ar" ? "السيارة غير موجودة" : "Car Not Found"}
          </h2>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            {language === "ar" ? "لم يتم العثور على السيارة المطلوبة" : "The requested car was not found"}
          </p>
          <Button asChild>
            <Link href="/cars">
              {language === "ar" ? "تصفح السيارات" : "Browse Cars"}
            </Link>
          </Button>
        </Card>
      </div>
    );
  }

  const images = car.images || [];
  const formatPrice = (price: string) => {
    return new Intl.NumberFormat('ar-SY').format(parseFloat(price));
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: car.title,
          text: `${car.title} - ${formatPrice(car.price)} ل.س`,
          url: window.location.href,
        });
      } catch (error) {
        // Fallback to clipboard
        navigator.clipboard.writeText(window.location.href);
        toast({
          title: "تم النسخ",
          description: "تم نسخ رابط السيارة"
        });
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "تم النسخ",
        description: "تم نسخ رابط السيارة"
      });
    }
  };

  const carFeatures = [
    { icon: Calendar, label: "السنة", value: car.year },
    { icon: Gauge, label: "المسافة", value: car.mileage ? `${car.mileage.toLocaleString()} كم` : "غير محدد" },
    { icon: Fuel, label: "الوقود", value: car.fuelType || "غير محدد" },
    { icon: Settings, label: "ناقل الحركة", value: car.transmission || "غير محدد" },
    { icon: Palette, label: "اللون", value: car.color || "غير محدد" },
    { icon: Car, label: "نوع الهيكل", value: car.bodyType || "غير محدد" },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <nav className="flex items-center space-x-2 text-sm text-gray-500 dark:text-gray-400 mb-6">
          <Link href="/" className="hover:text-primary">الرئيسية</Link>
          <span>/</span>
          <Link href="/cars" className="hover:text-primary">السيارات</Link>
          <span>/</span>
          <span className="text-gray-900 dark:text-white">{car.title}</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Image Gallery */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="relative mb-8"
            >
              <div className="relative rounded-2xl overflow-hidden bg-gray-200 dark:bg-gray-700">
                {images.length > 0 ? (
                  <>
                    <img
                      src={images[currentImageIndex]}
                      alt={car.title}
                      className="w-full h-96 object-cover"
                    />
                    
                    {images.length > 1 && (
                      <>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 text-white hover:bg-black/70"
                          onClick={() => setCurrentImageIndex(prev => 
                            prev === 0 ? images.length - 1 : prev - 1
                          )}
                        >
                          <ChevronLeft className="h-4 w-4" />
                        </Button>
                        
                        <Button
                          variant="ghost"
                          size="sm"
                          className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 text-white hover:bg-black/70"
                          onClick={() => setCurrentImageIndex(prev => 
                            prev === images.length - 1 ? 0 : prev + 1
                          )}
                        >
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                        
                        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                          {images.map((_, index) => (
                            <button
                              key={index}
                              className={`w-2 h-2 rounded-full ${
                                index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                              }`}
                              onClick={() => setCurrentImageIndex(index)}
                            />
                          ))}
                        </div>
                      </>
                    )}
                  </>
                ) : (
                  <div className="w-full h-96 flex items-center justify-center">
                    <Camera className="h-16 w-16 text-gray-400" />
                  </div>
                )}
                
                {/* Image Count & View Count */}
                <div className="absolute top-4 left-4 space-y-2">
                  {images.length > 0 && (
                    <div className="bg-black/50 text-white px-3 py-1 rounded-lg text-sm">
                      {currentImageIndex + 1} / {images.length}
                    </div>
                  )}
                  <div className="bg-black/50 text-white px-3 py-1 rounded-lg text-sm flex items-center">
                    <Eye className="h-4 w-4 mr-1" />
                    {car.viewCount || 0}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="absolute top-4 right-4 space-y-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="bg-white/90 hover:bg-white"
                    onClick={() => favoriteMutation.mutate()}
                    disabled={!user || favoriteMutation.isPending}
                  >
                    <Heart className="h-4 w-4 text-gray-600" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="bg-white/90 hover:bg-white"
                    onClick={handleShare}
                  >
                    <Share2 className="h-4 w-4 text-gray-600" />
                  </Button>
                </div>
              </div>

              {/* Thumbnail Gallery */}
              {images.length > 1 && (
                <div className="flex space-x-2 mt-4 overflow-x-auto pb-2">
                  {images.map((image, index) => (
                    <button
                      key={index}
                      className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 ${
                        index === currentImageIndex 
                          ? 'border-primary' 
                          : 'border-transparent'
                      }`}
                      onClick={() => setCurrentImageIndex(index)}
                    >
                      <img
                        src={image}
                        alt={`${car.title} ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </motion.div>

            {/* Car Details Tabs */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Tabs defaultValue="details" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="details">التفاصيل</TabsTrigger>
                  <TabsTrigger value="features">المواصفات</TabsTrigger>
                  <TabsTrigger value="seller">البائع</TabsTrigger>
                </TabsList>
                
                <TabsContent value="details" className="mt-6">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="text-xl font-semibold mb-4">وصف السيارة</h3>
                      {car.description ? (
                        <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                          {car.description}
                        </p>
                      ) : (
                        <p className="text-gray-500 dark:text-gray-400 italic">
                          لم يتم إضافة وصف لهذه السيارة
                        </p>
                      )}
                      
                      <Separator className="my-6" />
                      
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        {carFeatures.map((feature, index) => {
                          const IconComponent = feature.icon;
                          return (
                            <div key={index} className="flex items-center space-x-3">
                              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                                <IconComponent className="h-5 w-5 text-primary" />
                              </div>
                              <div>
                                <p className="text-sm text-gray-500 dark:text-gray-400">
                                  {feature.label}
                                </p>
                                <p className="font-medium text-gray-900 dark:text-white">
                                  {feature.value}
                                </p>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="features" className="mt-6">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="text-xl font-semibold mb-4">المواصفات والميزات</h3>
                      
                      {car.features && Array.isArray(car.features) && car.features.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {car.features.map((feature, index) => (
                            <div key={index} className="flex items-center space-x-2">
                              <div className="w-2 h-2 bg-primary rounded-full"></div>
                              <span className="text-gray-700 dark:text-gray-300">{feature}</span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-gray-500 dark:text-gray-400 italic">
                          لم يتم تحديد مواصفات إضافية لهذه السيارة
                        </p>
                      )}

                      <Separator className="my-6" />

                      {/* Condition Details */}
                      <div className="space-y-4">
                        <h4 className="font-semibold">حالة السيارة</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="flex justify-between">
                            <span>الحالة العامة:</span>
                            <Badge variant="secondary">{car.condition}</Badge>
                          </div>
                          {car.tireCondition && (
                            <div className="flex justify-between">
                              <span>حالة الإطارات:</span>
                              <Badge variant="secondary">{car.tireCondition}</Badge>
                            </div>
                          )}
                          {car.batteryCondition && (
                            <div className="flex justify-between">
                              <span>حالة البطارية:</span>
                              <Badge variant="secondary">{car.batteryCondition}</Badge>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="seller" className="mt-6">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="text-xl font-semibold mb-4">معلومات البائع</h3>
                      
                      <div className="flex items-center space-x-4 mb-6">
                        <Avatar className="w-16 h-16">
                          <AvatarImage src="" />
                          <AvatarFallback className="text-lg">
                            {car.sellerId.slice(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 className="font-semibold text-lg">
                            {car.dealershipId ? "معرض تجاري" : "مالك خاص"}
                          </h4>
                          <div className="flex items-center space-x-1">
                            <div className="flex text-yellow-400 text-sm">
                              {[...Array(5)].map((_, i) => (
                                <Star key={i} className="h-4 w-4 fill-current" />
                              ))}
                            </div>
                            <span className="text-sm text-gray-500">(4.8)</span>
                          </div>
                          <p className="text-sm text-gray-500 mt-1">
                            عضو منذ 2020
                          </p>
                        </div>
                      </div>

                      {/* Trust Indicators */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                        <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                          <Shield className="h-8 w-8 text-green-600 mx-auto mb-2" />
                          <p className="text-sm font-medium">موثق</p>
                        </div>
                        <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                          <TrendingUp className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                          <p className="text-sm font-medium">تقييم ممتاز</p>
                        </div>
                        <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                          <Clock className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                          <p className="text-sm font-medium">رد سريع</p>
                        </div>
                      </div>

                      <p className="text-gray-600 dark:text-gray-300 text-sm">
                        بائع موثوق مع سجل ممتاز في بيع السيارات عالية الجودة. 
                        يحرص على تقديم خدمة عملاء ممتازة وضمان رضا المشترين.
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Price & Action Card */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Card className="sticky top-24">
                <CardContent className="p-6">
                  <div className="text-center mb-6">
                    <div className="text-3xl font-bold text-primary mb-2">
                      {formatPrice(car.price)} ل.س
                    </div>
                    <div className="flex justify-center space-x-2">
                      {car.negotiable && (
                        <Badge variant="secondary">قابل للتفاوض</Badge>
                      )}
                      {car.installmentAvailable && (
                        <Badge variant="secondary">أقساط متاحة</Badge>
                      )}
                      {car.tradeInAccepted && (
                        <Badge variant="secondary">مقايضة مقبولة</Badge>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-center text-gray-500 dark:text-gray-400 mb-6">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span>{car.city}</span>
                  </div>

                  <div className="space-y-3">
                    <Dialog open={showContactDialog} onOpenChange={setShowContactDialog}>
                      <DialogTrigger asChild>
                        <Button className="w-full" disabled={!user}>
                          <MessageCircle className="h-4 w-4 mr-2" />
                          إرسال رسالة
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>إرسال رسالة للبائع</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <Textarea
                            placeholder="اكتب رسالتك هنا..."
                            value={message}
                            onChange={(e) => setMessage(e.target.value)}
                            rows={4}
                          />
                          <div className="flex space-x-2">
                            <Button
                              onClick={() => sendMessageMutation.mutate(message)}
                              disabled={!message.trim() || sendMessageMutation.isPending}
                              className="flex-1"
                            >
                              إرسال
                            </Button>
                            <Button
                              variant="outline"
                              onClick={() => setShowContactDialog(false)}
                            >
                              إلغاء
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>

                    <Button variant="outline" className="w-full">
                      <Phone className="h-4 w-4 mr-2" />
                      إظهار رقم الهاتف
                    </Button>

                    {!user && (
                      <p className="text-sm text-gray-500 dark:text-gray-400 text-center">
                        <Link href="/auth/login" className="text-primary hover:underline">
                          سجل الدخول
                        </Link>{" "}
                        للتواصل مع البائع
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Similar Cars */}
            {similarCars.length > 0 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 }}
              >
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold mb-4">سيارات مشابهة</h3>
                    <div className="space-y-4">
                      {similarCars.map((similarCar) => (
                        <Link key={similarCar.id} href={`/cars/${similarCar.id}`}>
                          <div className="flex space-x-3 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                            <img
                              src={similarCar.images?.[0] || "https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2"}
                              alt={similarCar.title}
                              className="w-16 h-16 object-cover rounded-lg"
                            />
                            <div className="flex-1 min-w-0">
                              <h4 className="font-medium text-sm truncate">
                                {similarCar.title}
                              </h4>
                              <p className="text-xs text-gray-500 dark:text-gray-400">
                                {similarCar.year} • {similarCar.city}
                              </p>
                              <p className="text-sm font-semibold text-primary">
                                {formatPrice(similarCar.price)} ل.س
                              </p>
                            </div>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
