import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import SearchFilters from "@/components/search-filters";
import CarCard from "@/components/car-card";
import { useLanguage } from "@/components/language-provider";
import { motion } from "framer-motion";
import { Filter, Grid, List, SlidersHorizontal, Search, X } from "lucide-react";
import { CAR_BRANDS, CAR_BODY_TYPES, SYRIAN_CITIES, FUEL_TYPES, TRANSMISSION_TYPES, CAR_CONDITIONS } from "@/lib/constants";

export default function Cars() {
  const [, setLocation] = useLocation();
  const { t, language } = useLanguage();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    search: "",
    brand: "",
    bodyType: "",
    city: "",
    fuelType: "",
    transmission: "",
    condition: "",
    minPrice: [0],
    maxPrice: [100000000],
    minYear: [2000],
    maxYear: [2024],
    negotiable: false,
    installmentAvailable: false,
    tradeInAccepted: false,
  });

  // Parse URL parameters on mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const urlFilters = { ...filters };
    
    params.forEach((value, key) => {
      if (key in urlFilters) {
        if (key === 'minPrice' || key === 'maxPrice' || key === 'minYear' || key === 'maxYear') {
          urlFilters[key] = [parseInt(value)];
        } else if (key === 'negotiable' || key === 'installmentAvailable' || key === 'tradeInAccepted') {
          urlFilters[key] = value === 'true';
        } else {
          urlFilters[key] = value;
        }
      }
    });
    
    setFilters(urlFilters);
  }, []);

  // Fetch cars with filters
  const { data: cars = [], isLoading, error } = useQuery({
    queryKey: ['/api/cars', filters],
    queryFn: async () => {
      const params = new URLSearchParams();
      
      Object.entries(filters).forEach(([key, value]) => {
        if (value && value !== "" && 
            !(Array.isArray(value) && (value[0] === 0 || value[0] === 2000 || value[0] === 2024 || value[0] === 100000000))) {
          if (Array.isArray(value)) {
            params.set(key, value[0].toString());
          } else {
            params.set(key, value.toString());
          }
        }
      });

      const response = await fetch(`/api/cars?${params.toString()}`);
      if (!response.ok) throw new Error('Failed to fetch cars');
      return response.json();
    },
  });

  const updateFilters = (newFilters: Partial<typeof filters>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
    
    // Update URL without triggering navigation
    const params = new URLSearchParams();
    const updatedFilters = { ...filters, ...newFilters };
    
    Object.entries(updatedFilters).forEach(([key, value]) => {
      if (value && value !== "" && 
          !(Array.isArray(value) && (value[0] === 0 || value[0] === 2000 || value[0] === 2024 || value[0] === 100000000))) {
        if (Array.isArray(value)) {
          params.set(key, value[0].toString());
        } else {
          params.set(key, value.toString());
        }
      }
    });
    
    window.history.replaceState({}, '', `${window.location.pathname}?${params.toString()}`);
  };

  const clearFilters = () => {
    const defaultFilters = {
      search: "",
      brand: "",
      bodyType: "",
      city: "",
      fuelType: "",
      transmission: "",
      condition: "",
      minPrice: [0],
      maxPrice: [100000000],
      minYear: [2000],
      maxYear: [2024],
      negotiable: false,
      installmentAvailable: false,
      tradeInAccepted: false,
    };
    setFilters(defaultFilters);
    window.history.replaceState({}, '', window.location.pathname);
  };

  const getActiveFiltersCount = () => {
    let count = 0;
    Object.entries(filters).forEach(([key, value]) => {
      if (key === 'search' && value) count++;
      else if (key === 'brand' && value) count++;
      else if (key === 'bodyType' && value) count++;
      else if (key === 'city' && value) count++;
      else if (key === 'fuelType' && value) count++;
      else if (key === 'transmission' && value) count++;
      else if (key === 'condition' && value) count++;
      else if (key === 'negotiable' && value) count++;
      else if (key === 'installmentAvailable' && value) count++;
      else if (key === 'tradeInAccepted' && value) count++;
      else if (key === 'minPrice' && Array.isArray(value) && value[0] > 0) count++;
      else if (key === 'maxPrice' && Array.isArray(value) && value[0] < 100000000) count++;
      else if (key === 'minYear' && Array.isArray(value) && value[0] > 2000) count++;
      else if (key === 'maxYear' && Array.isArray(value) && value[0] < 2024) count++;
    });
    return count;
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
              {language === "ar" ? "تصفح السيارات" : "Browse Cars"}
            </h1>
            <p className="text-gray-600 dark:text-gray-300">
              {cars.length} {language === "ar" ? "سيارة" : "cars"} {language === "ar" ? "متاحة" : "available"}
            </p>
          </div>
          
          <div className="flex items-center space-x-4 mt-4 md:mt-0">
            {/* View Toggle */}
            <div className="flex items-center space-x-2 bg-white dark:bg-gray-800 rounded-lg p-1">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>

            {/* Filter Toggle */}
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className="relative"
            >
              <Filter className="h-4 w-4 mr-2" />
              {language === "ar" ? "تصفية" : "Filter"}
              {getActiveFiltersCount() > 0 && (
                <Badge variant="destructive" className="ml-2 h-5 w-5 rounded-full p-0 text-xs">
                  {getActiveFiltersCount()}
                </Badge>
              )}
            </Button>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          {showFilters && (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="w-full lg:w-80"
            >
              <Card className="sticky top-24">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                      {language === "ar" ? "الفلاتر" : "Filters"}
                    </h3>
                    <div className="flex space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={clearFilters}
                        disabled={getActiveFiltersCount() === 0}
                      >
                        {language === "ar" ? "إعادة تعيين" : "Reset"}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowFilters(false)}
                        className="lg:hidden"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-6">
                    {/* Search */}
                    <div>
                      <Label className="text-sm font-medium mb-2 block">
                        {language === "ar" ? "البحث" : "Search"}
                      </Label>
                      <div className="relative">
                        <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          placeholder={language === "ar" ? "ابحث عن سيارة..." : "Search for a car..."}
                          value={filters.search}
                          onChange={(e) => updateFilters({ search: e.target.value })}
                          className="pl-10"
                        />
                      </div>
                    </div>

                    <Separator />

                    {/* Brand */}
                    <div>
                      <Label className="text-sm font-medium mb-2 block">
                        {language === "ar" ? "الماركة" : "Brand"}
                      </Label>
                      <Select value={filters.brand} onValueChange={(value) => updateFilters({ brand: value })}>
                        <SelectTrigger>
                          <SelectValue placeholder={language === "ar" ? "اختر الماركة" : "Select brand"} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">{language === "ar" ? "جميع الماركات" : "All brands"}</SelectItem>
                          {CAR_BRANDS.map(brand => (
                            <SelectItem key={brand} value={brand}>{brand}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Body Type */}
                    <div>
                      <Label className="text-sm font-medium mb-2 block">
                        {language === "ar" ? "نوع الهيكل" : "Body Type"}
                      </Label>
                      <Select value={filters.bodyType} onValueChange={(value) => updateFilters({ bodyType: value })}>
                        <SelectTrigger>
                          <SelectValue placeholder={language === "ar" ? "اختر النوع" : "Select type"} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">{language === "ar" ? "جميع الأنواع" : "All types"}</SelectItem>
                          {CAR_BODY_TYPES.map(type => (
                            <SelectItem key={type} value={type}>{type}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* City */}
                    <div>
                      <Label className="text-sm font-medium mb-2 block">
                        {language === "ar" ? "المدينة" : "City"}
                      </Label>
                      <Select value={filters.city} onValueChange={(value) => updateFilters({ city: value })}>
                        <SelectTrigger>
                          <SelectValue placeholder={language === "ar" ? "اختر المدينة" : "Select city"} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">{language === "ar" ? "جميع المدن" : "All cities"}</SelectItem>
                          {SYRIAN_CITIES.map(city => (
                            <SelectItem key={city} value={city}>{city}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <Separator />

                    {/* Price Range */}
                    <div>
                      <Label className="text-sm font-medium mb-2 block">
                        {language === "ar" ? "نطاق السعر (ل.س)" : "Price Range (SYP)"}
                      </Label>
                      <div className="space-y-4">
                        <div>
                          <Label className="text-xs text-gray-500">
                            {language === "ar" ? "الحد الأدنى:" : "Min:"} {filters.minPrice[0].toLocaleString()}
                          </Label>
                          <Slider
                            value={filters.minPrice}
                            onValueChange={(value) => updateFilters({ minPrice: value })}
                            max={50000000}
                            step={1000000}
                            className="mt-2"
                          />
                        </div>
                        <div>
                          <Label className="text-xs text-gray-500">
                            {language === "ar" ? "الحد الأقصى:" : "Max:"} {filters.maxPrice[0].toLocaleString()}
                          </Label>
                          <Slider
                            value={filters.maxPrice}
                            onValueChange={(value) => updateFilters({ maxPrice: value })}
                            max={100000000}
                            step={1000000}
                            className="mt-2"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Year Range */}
                    <div>
                      <Label className="text-sm font-medium mb-2 block">
                        {language === "ar" ? "سنة الصنع" : "Year"}
                      </Label>
                      <div className="space-y-4">
                        <div>
                          <Label className="text-xs text-gray-500">
                            {language === "ar" ? "من:" : "From:"} {filters.minYear[0]}
                          </Label>
                          <Slider
                            value={filters.minYear}
                            onValueChange={(value) => updateFilters({ minYear: value })}
                            min={2000}
                            max={2024}
                            step={1}
                            className="mt-2"
                          />
                        </div>
                        <div>
                          <Label className="text-xs text-gray-500">
                            {language === "ar" ? "إلى:" : "To:"} {filters.maxYear[0]}
                          </Label>
                          <Slider
                            value={filters.maxYear}
                            onValueChange={(value) => updateFilters({ maxYear: value })}
                            min={2000}
                            max={2024}
                            step={1}
                            className="mt-2"
                          />
                        </div>
                      </div>
                    </div>

                    <Separator />

                    {/* Additional Filters */}
                    <div className="space-y-4">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="negotiable"
                          checked={filters.negotiable}
                          onCheckedChange={(checked) => updateFilters({ negotiable: !!checked })}
                        />
                        <Label htmlFor="negotiable" className="text-sm">
                          {language === "ar" ? "قابل للتفاوض" : "Negotiable"}
                        </Label>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="installment"
                          checked={filters.installmentAvailable}
                          onCheckedChange={(checked) => updateFilters({ installmentAvailable: !!checked })}
                        />
                        <Label htmlFor="installment" className="text-sm">
                          {language === "ar" ? "أقساط متاحة" : "Installments Available"}
                        </Label>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="tradein"
                          checked={filters.tradeInAccepted}
                          onCheckedChange={(checked) => updateFilters({ tradeInAccepted: !!checked })}
                        />
                        <Label htmlFor="tradein" className="text-sm">
                          {language === "ar" ? "مقايضة مقبولة" : "Trade-in Accepted"}
                        </Label>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Main Content */}
          <div className="flex-1">
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(9)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="bg-gray-200 dark:bg-gray-700 rounded-2xl h-80"></div>
                  </div>
                ))}
              </div>
            ) : error ? (
              <Card className="p-8 text-center">
                <p className="text-gray-500 dark:text-gray-400">
                  {language === "ar" ? "حدث خطأ في تحميل السيارات" : "Error loading cars"}
                </p>
              </Card>
            ) : cars.length === 0 ? (
              <Card className="p-8 text-center">
                <p className="text-gray-500 dark:text-gray-400">
                  {language === "ar" ? "لا توجد سيارات تطابق البحث" : "No cars match your search"}
                </p>
                <Button 
                  variant="outline" 
                  onClick={clearFilters}
                  className="mt-4"
                >
                  {language === "ar" ? "إعادة تعيين البحث" : "Reset Search"}
                </Button>
              </Card>
            ) : (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className={
                  viewMode === 'grid'
                    ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                    : "space-y-6"
                }
              >
                {cars.map((car, index) => (
                  <motion.div
                    key={car.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <CarCard 
                      car={car} 
                      className={viewMode === 'list' ? 'w-full' : ''}
                    />
                  </motion.div>
                ))}
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
