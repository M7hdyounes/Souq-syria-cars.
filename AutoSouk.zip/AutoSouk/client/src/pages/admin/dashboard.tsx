import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { motion } from "framer-motion";
import { 
  Users, Car, MessageSquare, TrendingUp, Eye, CheckCircle, 
  XCircle, AlertTriangle, BarChart3, PieChart, Activity,
  Filter, Search, MoreVertical, Edit, Trash2, UserCheck,
  UserX, Flag, Clock, DollarSign, MapPin, Calendar
} from "lucide-react";

export default function AdminDashboard() {
  const { admin, adminLogout } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedComplaint, setSelectedComplaint] = useState<any>(null);
  const [complaintResponse, setComplaintResponse] = useState("");

  // Redirect if not admin
  if (!admin) {
    window.location.href = "/admin/login";
    return null;
  }

  // Fetch dashboard stats
  const { data: stats = {}, isLoading: statsLoading } = useQuery({
    queryKey: ['/api/admin/stats'],
  });

  // Fetch all cars for admin management
  const { data: cars = [], isLoading: carsLoading } = useQuery({
    queryKey: ['/api/admin/cars'],
  });

  // Fetch complaints
  const { data: complaints = [], isLoading: complaintsLoading } = useQuery({
    queryKey: ['/api/admin/complaints'],
  });

  // Approve car mutation
  const approveCarMutation = useMutation({
    mutationFn: async (carId: string) => {
      return apiRequest("PUT", `/api/admin/cars/${carId}/approve`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/cars'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/stats'] });
      toast({
        title: "تم الموافقة",
        description: "تم الموافقة على الإعلان بنجاح"
      });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Delete car mutation
  const deleteCarMutation = useMutation({
    mutationFn: async (carId: string) => {
      return apiRequest("DELETE", `/api/cars/${carId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/cars'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/stats'] });
      toast({
        title: "تم الحذف",
        description: "تم حذف الإعلان بنجاح"
      });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Respond to complaint mutation
  const respondToComplaintMutation = useMutation({
    mutationFn: async ({ id, response }: { id: string; response: string }) => {
      return apiRequest("PUT", `/api/admin/complaints/${id}`, {
        status: "resolved",
        response
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/complaints'] });
      toast({
        title: "تم الرد",
        description: "تم الرد على الشكوى بنجاح"
      });
      setSelectedComplaint(null);
      setComplaintResponse("");
    },
    onError: (error: any) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const dashboardStats = [
    {
      title: "إجمالي المستخدمين",
      value: stats.totalUsers || 0,
      icon: Users,
      color: "bg-blue-500",
      change: "+12%"
    },
    {
      title: "إجمالي السيارات",
      value: stats.totalCars || 0,
      icon: Car,
      color: "bg-green-500",
      change: "+8%"
    },
    {
      title: "في انتظار الموافقة",
      value: stats.unapprovedCars || 0,
      icon: Clock,
      color: "bg-yellow-500",
      change: "5 جديد"
    },
    {
      title: "الشكاوى المعلقة",
      value: stats.pendingComplaints || 0,
      icon: Flag,
      color: "bg-red-500",
      change: "يحتاج متابعة"
    }
  ];

  const formatPrice = (price: string) => {
    return new Intl.NumberFormat('ar-SY').format(parseFloat(price));
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 bg-red-600 rounded-lg flex items-center justify-center">
                <Car className="h-5 w-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900 dark:text-white">
                  لوحة التحكم الإدارية
                </h1>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  سوق سوريا للسيارات
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900 dark:text-white">
                  {admin.email}
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  مدير النظام
                </p>
              </div>
              <Button variant="outline" onClick={adminLogout}>
                تسجيل الخروج
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
        >
          {dashboardStats.map((stat, index) => {
            const IconComponent = stat.icon;
            return (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                        {stat.title}
                      </p>
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">
                        {stat.value.toLocaleString()}
                      </p>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        {stat.change}
                      </p>
                    </div>
                    <div className={`w-12 h-12 ${stat.color} rounded-lg flex items-center justify-center`}>
                      <IconComponent className="h-6 w-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </motion.div>

        {/* Main Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Tabs defaultValue="cars" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="cars">إدارة السيارات</TabsTrigger>
              <TabsTrigger value="users">إدارة المستخدمين</TabsTrigger>
              <TabsTrigger value="complaints">الشكاوى</TabsTrigger>
              <TabsTrigger value="analytics">التحليلات</TabsTrigger>
            </TabsList>

            {/* Cars Management */}
            <TabsContent value="cars" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>إدارة السيارات</span>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">
                        <Filter className="h-4 w-4 mr-2" />
                        تصفية
                      </Button>
                      <Button variant="outline" size="sm">
                        <Search className="h-4 w-4 mr-2" />
                        بحث
                      </Button>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {carsLoading ? (
                    <div className="space-y-4">
                      {[...Array(5)].map((_, i) => (
                        <div key={i} className="animate-pulse">
                          <div className="bg-gray-200 dark:bg-gray-700 rounded h-16"></div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>السيارة</TableHead>
                          <TableHead>البائع</TableHead>
                          <TableHead>السعر</TableHead>
                          <TableHead>المدينة</TableHead>
                          <TableHead>الحالة</TableHead>
                          <TableHead>تاريخ الإضافة</TableHead>
                          <TableHead>الإجراءات</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {cars.map((car: any) => (
                          <TableRow key={car.id}>
                            <TableCell>
                              <div className="flex items-center space-x-3">
                                <img
                                  src={car.images?.[0] || "https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2"}
                                  alt={car.title}
                                  className="w-12 h-12 object-cover rounded-lg"
                                />
                                <div>
                                  <p className="font-medium text-gray-900 dark:text-white">
                                    {car.title}
                                  </p>
                                  <p className="text-sm text-gray-500 dark:text-gray-400">
                                    {car.brand} {car.model} {car.year}
                                  </p>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <p className="text-sm text-gray-900 dark:text-white">
                                {car.sellerId.slice(0, 8)}...
                              </p>
                            </TableCell>
                            <TableCell>
                              <p className="font-medium text-gray-900 dark:text-white">
                                {formatPrice(car.price)} ل.س
                              </p>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center space-x-1">
                                <MapPin className="h-4 w-4 text-gray-400" />
                                <span className="text-sm text-gray-600 dark:text-gray-300">
                                  {car.city}
                                </span>
                              </div>
                            </TableCell>
                            <TableCell>
                              {car.isApproved ? (
                                <Badge className="bg-green-100 text-green-800">
                                  <CheckCircle className="h-3 w-3 mr-1" />
                                  معتمد
                                </Badge>
                              ) : (
                                <Badge variant="secondary">
                                  <Clock className="h-3 w-3 mr-1" />
                                  في انتظار الموافقة
                                </Badge>
                              )}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center space-x-1">
                                <Calendar className="h-4 w-4 text-gray-400" />
                                <span className="text-sm text-gray-600 dark:text-gray-300">
                                  {new Date(car.createdAt!).toLocaleDateString('ar-SY')}
                                </span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                {!car.isApproved && (
                                  <Button
                                    size="sm"
                                    onClick={() => approveCarMutation.mutate(car.id)}
                                    disabled={approveCarMutation.isPending}
                                  >
                                    <CheckCircle className="h-4 w-4 mr-1" />
                                    موافقة
                                  </Button>
                                )}
                                <Button
                                  variant="outline"
                                  size="sm"
                                >
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="destructive"
                                  size="sm"
                                  onClick={() => {
                                    if (confirm("هل أنت متأكد من حذف هذا الإعلان؟")) {
                                      deleteCarMutation.mutate(car.id);
                                    }
                                  }}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Users Management */}
            <TabsContent value="users" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>إدارة المستخدمين</CardTitle>
                </CardHeader>
                <CardContent>
                  <Alert>
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>
                      إدارة المستخدمين قيد التطوير. سيتم إضافة هذه الميزة قريباً.
                    </AlertDescription>
                  </Alert>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Complaints */}
            <TabsContent value="complaints" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>إدارة الشكاوى</span>
                    <Badge variant="destructive">
                      {complaints.filter((c: any) => c.status === 'pending').length} معلقة
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {complaintsLoading ? (
                    <div className="space-y-4">
                      {[...Array(3)].map((_, i) => (
                        <div key={i} className="animate-pulse">
                          <div className="bg-gray-200 dark:bg-gray-700 rounded h-20"></div>
                        </div>
                      ))}
                    </div>
                  ) : complaints.length === 0 ? (
                    <div className="text-center py-8">
                      <Flag className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                        لا توجد شكاوى
                      </h3>
                      <p className="text-gray-500 dark:text-gray-400">
                        لا توجد شكاوى مسجلة في النظام
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {complaints.map((complaint: any) => (
                        <Card key={complaint.id} className="border-l-4 border-l-primary">
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <div className="flex items-center space-x-2 mb-2">
                                  <h4 className="font-semibold text-gray-900 dark:text-white">
                                    {complaint.subject}
                                  </h4>
                                  <Badge
                                    variant={complaint.status === 'pending' ? 'destructive' : 'default'}
                                  >
                                    {complaint.status === 'pending' ? 'معلق' : 'تم الحل'}
                                  </Badge>
                                </div>
                                
                                <p className="text-gray-600 dark:text-gray-300 mb-3">
                                  {complaint.description}
                                </p>
                                
                                <div className="flex items-center space-x-4 text-sm text-gray-500 dark:text-gray-400">
                                  <span>المستخدم: {complaint.userId.slice(0, 8)}...</span>
                                  <span>•</span>
                                  <span>{new Date(complaint.createdAt!).toLocaleDateString('ar-SY')}</span>
                                </div>

                                {complaint.response && (
                                  <div className="mt-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                                    <p className="text-sm text-green-800 dark:text-green-200">
                                      <strong>الرد:</strong> {complaint.response}
                                    </p>
                                  </div>
                                )}
                              </div>
                              
                              {complaint.status === 'pending' && (
                                <Dialog>
                                  <DialogTrigger asChild>
                                    <Button
                                      size="sm"
                                      onClick={() => setSelectedComplaint(complaint)}
                                    >
                                      رد على الشكوى
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent>
                                    <DialogHeader>
                                      <DialogTitle>الرد على الشكوى</DialogTitle>
                                    </DialogHeader>
                                    <div className="space-y-4">
                                      <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                                        <h4 className="font-medium mb-2">{complaint.subject}</h4>
                                        <p className="text-sm text-gray-600 dark:text-gray-300">
                                          {complaint.description}
                                        </p>
                                      </div>
                                      
                                      <Textarea
                                        placeholder="اكتب ردك على الشكوى..."
                                        value={complaintResponse}
                                        onChange={(e) => setComplaintResponse(e.target.value)}
                                        rows={4}
                                      />
                                      
                                      <div className="flex space-x-2">
                                        <Button
                                          onClick={() => respondToComplaintMutation.mutate({
                                            id: complaint.id,
                                            response: complaintResponse
                                          })}
                                          disabled={!complaintResponse.trim() || respondToComplaintMutation.isPending}
                                          className="flex-1"
                                        >
                                          إرسال الرد
                                        </Button>
                                      </div>
                                    </div>
                                  </DialogContent>
                                </Dialog>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Analytics */}
            <TabsContent value="analytics" className="mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <BarChart3 className="h-5 w-5" />
                      <span>إحصائيات عامة</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600 dark:text-gray-300">إجمالي المستخدمين</span>
                        <span className="font-semibold">{stats.totalUsers || 0}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600 dark:text-gray-300">إجمالي السيارات</span>
                        <span className="font-semibold">{stats.totalCars || 0}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600 dark:text-gray-300">إجمالي المعارض</span>
                        <span className="font-semibold">{stats.totalDealerships || 0}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600 dark:text-gray-300">الشكاوى المعلقة</span>
                        <span className="font-semibold text-red-600">{stats.pendingComplaints || 0}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Activity className="h-5 w-5" />
                      <span>النشاط الأخير</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Alert>
                      <TrendingUp className="h-4 w-4" />
                      <AlertDescription>
                        التحليلات المتقدمة والرسوم البيانية قيد التطوير.
                      </AlertDescription>
                    </Alert>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}
