import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/components/language-provider";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertCarSchema } from "@shared/schema";
import { motion } from "framer-motion";
import { 
  Upload, X, Car, Camera, DollarSign, MapPin, 
  Settings, Palette, Calendar, Gauge, CheckCircle, AlertCircle
} from "lucide-react";
import { 
  CAR_BRANDS, CAR_BODY_TYPES, SYRIAN_CITIES, FUEL_TYPES, 
  TRANSMISSION_TYPES, CAR_CONDITIONS, FILE_UPLOAD_LIMITS 
} from "@/lib/constants";

const formSchema = insertCarSchema.extend({
  dealershipId: insertCarSchema.shape.dealershipId.optional(),
});

export default function AddCar() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { t, language } = useLanguage();
  const { toast } = useToast();
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [currentStep, setCurrentStep] = useState(0);

  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      brand: "",
      model: "",
      year: new Date().getFullYear(),
      price: "",
      mileage: undefined,
      fuelType: "",
      transmission: "",
      bodyType: "",
      color: "",
      condition: "",
      city: "",
      images: [],
      interiorImages: [],
      exteriorImages: [],
      features: [],
      tireCondition: "",
      batteryCondition: "",
      negotiable: true,
      installmentAvailable: false,
      tradeInAccepted: false,
    },
  });

  const createCarMutation = useMutation({
    mutationFn: async (data: any) => {
      if (!user) throw new Error("يجب تسجيل الدخول أولاً");
      
      return apiRequest("POST", "/api/cars", {
        ...data,
        sellerId: user.id,
        images: uploadedImages,
      });
    },
    onSuccess: (response) => {
      toast({
        title: "تم بنجاح",
        description: "تم إضافة إعلان السيارة بنجاح. سيتم مراجعته من قبل الإدارة."
      });
      setLocation("/profile");
    },
    onError: (error: any) => {
      toast({
        title: "خطأ",
        description: error.message || "حدث خطأ أثناء إضافة الإعلان",
        variant: "destructive"
      });
    }
  });

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Card className="p-8 text-center max-w-md mx-4">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            {language === "ar" ? "تسجيل الدخول مطلوب" : "Login Required"}
          </h2>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            {language === "ar" ? "يجب تسجيل الدخول لإضافة إعلان سيارة" : "You need to login to add a car listing"}
          </p>
          <Button asChild>
            <a href="/auth/login">
              {language === "ar" ? "تسجيل الدخول" : "Login"}
            </a>
          </Button>
        </Card>
      </div>
    );
  }

  const steps = [
    {
      title: "معلومات أساسية",
      titleEn: "Basic Information",
      icon: Car,
      fields: ["title", "brand", "model", "year", "bodyType"]
    },
    {
      title: "تفاصيل السيارة",
      titleEn: "Car Details", 
      icon: Settings,
      fields: ["condition", "mileage", "fuelType", "transmission", "color"]
    },
    {
      title: "السعر والموقع",
      titleEn: "Price & Location",
      icon: DollarSign,
      fields: ["price", "city", "negotiable", "installmentAvailable", "tradeInAccepted"]
    },
    {
      title: "الصور والوصف",
      titleEn: "Photos & Description",
      icon: Camera,
      fields: ["images", "description", "features"]
    }
  ];

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    
    // Validate file types and sizes
    const validFiles = files.filter(file => {
      if (!FILE_UPLOAD_LIMITS.allowedTypes.includes(file.type)) {
        toast({
          title: "نوع ملف غير مدعوم",
          description: "يُسمح فقط بملفات JPEG، PNG، و WebP",
          variant: "destructive"
        });
        return false;
      }
      
      if (file.size > FILE_UPLOAD_LIMITS.maxSize) {
        toast({
          title: "حجم الملف كبير جداً",
          description: "حجم الملف يجب أن يكون أقل من 5 ميجابايت",
          variant: "destructive"
        });
        return false;
      }
      
      return true;
    });

    // Check total number of images
    if (uploadedImages.length + validFiles.length > FILE_UPLOAD_LIMITS.maxFiles) {
      toast({
        title: "عدد كبير من الصور",
        description: `يمكن رفع ${FILE_UPLOAD_LIMITS.maxFiles} صور كحد أقصى`,
        variant: "destructive"
      });
      return;
    }

    // Convert files to base64 URLs (in a real app, upload to storage service)
    validFiles.forEach(file => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setUploadedImages(prev => [...prev, result]);
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setUploadedImages(prev => prev.filter((_, i) => i !== index));
  };

  const onSubmit = (data: any) => {
    createCarMutation.mutate(data);
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const isStepValid = (stepIndex: number) => {
    const step = steps[stepIndex];
    const errors = form.formState.errors;
    return !step.fields.some(field => errors[field]);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            {language === "ar" ? "أضف إعلان سيارة" : "Add Car Listing"}
          </h1>
          <p className="text-gray-600 dark:text-gray-300">
            {language === "ar" ? "املأ النموذج أدناه لإضافة إعلان سيارتك" : "Fill out the form below to add your car listing"}
          </p>
        </motion.div>

        {/* Progress Steps */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <div className="flex items-center justify-between mb-4">
            {steps.map((step, index) => {
              const IconComponent = step.icon;
              const isActive = index === currentStep;
              const isCompleted = index < currentStep || isStepValid(index);
              
              return (
                <div key={index} className="flex-1 relative">
                  <div className="flex flex-col items-center">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center border-2 ${
                      isActive 
                        ? 'border-primary bg-primary text-white' 
                        : isCompleted
                        ? 'border-green-500 bg-green-500 text-white'
                        : 'border-gray-300 bg-white text-gray-400'
                    }`}>
                      {isCompleted && !isActive ? (
                        <CheckCircle className="h-6 w-6" />
                      ) : (
                        <IconComponent className="h-6 w-6" />
                      )}
                    </div>
                    <span className={`text-sm mt-2 font-medium ${
                      isActive ? 'text-primary' : 'text-gray-500'
                    }`}>
                      {language === "ar" ? step.title : step.titleEn}
                    </span>
                  </div>
                  
                  {index < steps.length - 1 && (
                    <div className={`absolute top-6 left-1/2 w-full h-0.5 ${
                      index < currentStep ? 'bg-green-500' : 'bg-gray-300'
                    }`} style={{ transform: 'translateX(50%)' }} />
                  )}
                </div>
              );
            })}
          </div>
        </motion.div>

        {/* Form */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    {React.createElement(steps[currentStep].icon, { className: "h-6 w-6" })}
                    <span>{language === "ar" ? steps[currentStep].title : steps[currentStep].titleEn}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Step 0: Basic Information */}
                  {currentStep === 0 && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem className="md:col-span-2">
                            <FormLabel>عنوان الإعلان *</FormLabel>
                            <FormControl>
                              <Input placeholder="مثال: تويوتا كامري 2020 فل كامل" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="brand"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>الماركة *</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر الماركة" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {CAR_BRANDS.map(brand => (
                                  <SelectItem key={brand} value={brand}>{brand}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="model"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>الموديل *</FormLabel>
                            <FormControl>
                              <Input placeholder="مثال: كامري" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="year"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>سنة الصنع *</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min="1990" 
                                max={new Date().getFullYear()}
                                {...field}
                                onChange={(e) => field.onChange(parseInt(e.target.value))}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="bodyType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>نوع الهيكل *</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر نوع الهيكل" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {CAR_BODY_TYPES.map(type => (
                                  <SelectItem key={type} value={type}>{type}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  )}

                  {/* Step 1: Car Details */}
                  {currentStep === 1 && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="condition"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>حالة السيارة *</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر الحالة" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {CAR_CONDITIONS.map(condition => (
                                  <SelectItem key={condition} value={condition}>{condition}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="mileage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>المسافة المقطوعة (كم)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="مثال: 50000"
                                {...field}
                                onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="fuelType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>نوع الوقود</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر نوع الوقود" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {FUEL_TYPES.map(type => (
                                  <SelectItem key={type} value={type}>{type}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="transmission"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>ناقل الحركة</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر ناقل الحركة" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {TRANSMISSION_TYPES.map(type => (
                                  <SelectItem key={type} value={type}>{type}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="color"
                        render={({ field }) => (
                          <FormItem className="md:col-span-2">
                            <FormLabel>اللون</FormLabel>
                            <FormControl>
                              <Input placeholder="مثال: أبيض، أسود، فضي" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  )}

                  {/* Step 2: Price & Location */}
                  {currentStep === 2 && (
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="price"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>السعر (ل.س) *</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="مثال: 25000000"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="city"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>المدينة *</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="اختر المدينة" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {SYRIAN_CITIES.map(city => (
                                    <SelectItem key={city} value={city}>{city}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <Separator />

                      <div className="space-y-4">
                        <h4 className="font-medium text-gray-900 dark:text-white">خيارات البيع</h4>
                        
                        <FormField
                          control={form.control}
                          name="negotiable"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>السعر قابل للتفاوض</FormLabel>
                                <p className="text-sm text-gray-500">
                                  السماح للمشترين بالتفاوض على السعر
                                </p>
                              </div>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="installmentAvailable"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>دفع بالأقساط متاح</FormLabel>
                                <p className="text-sm text-gray-500">
                                  إمكانية الدفع بالتقسيط
                                </p>
                              </div>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="tradeInAccepted"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>قبول المقايضة</FormLabel>
                                <p className="text-sm text-gray-500">
                                  قبول تبديل السيارة بسيارة أخرى
                                </p>
                              </div>
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                  )}

                  {/* Step 3: Photos & Description */}
                  {currentStep === 3 && (
                    <div className="space-y-6">
                      {/* Image Upload */}
                      <div>
                        <h4 className="font-medium text-gray-900 dark:text-white mb-4">صور السيارة</h4>
                        
                        <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
                          <Upload className="h-8 w-8 text-gray-400 mx-auto mb-4" />
                          <p className="text-gray-600 dark:text-gray-300 mb-4">
                            اسحب وأفلت الصور هنا أو انقر للاختيار
                          </p>
                          <input
                            type="file"
                            multiple
                            accept="image/*"
                            onChange={handleImageUpload}
                            className="hidden"
                            id="image-upload"
                          />
                          <Button type="button" variant="outline" asChild>
                            <label htmlFor="image-upload" className="cursor-pointer">
                              اختر الصور
                            </label>
                          </Button>
                          <p className="text-xs text-gray-500 mt-2">
                            يمكن رفع حتى {FILE_UPLOAD_LIMITS.maxFiles} صور، كل صورة أقل من 5 ميجابايت
                          </p>
                        </div>

                        {/* Uploaded Images */}
                        {uploadedImages.length > 0 && (
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                            {uploadedImages.map((image, index) => (
                              <div key={index} className="relative">
                                <img
                                  src={image}
                                  alt={`Upload ${index + 1}`}
                                  className="w-full h-24 object-cover rounded-lg"
                                />
                                <Button
                                  type="button"
                                  variant="destructive"
                                  size="sm"
                                  className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0"
                                  onClick={() => removeImage(index)}
                                >
                                  <X className="h-3 w-3" />
                                </Button>
                                {index === 0 && (
                                  <Badge className="absolute bottom-1 left-1 text-xs">
                                    الصورة الرئيسية
                                  </Badge>
                                )}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      <Separator />

                      {/* Description */}
                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>وصف السيارة</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="اكتب وصف تفصيلي للسيارة، حالتها، مميزاتها، وأي معلومات إضافية..."
                                className="min-h-[120px]"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Navigation Buttons */}
              <div className="flex justify-between">
                <Button
                  type="button"
                  variant="outline"
                  onClick={prevStep}
                  disabled={currentStep === 0}
                >
                  السابق
                </Button>

                <div className="flex space-x-4">
                  {currentStep < steps.length - 1 ? (
                    <Button type="button" onClick={nextStep}>
                      التالي
                    </Button>
                  ) : (
                    <Button 
                      type="submit" 
                      disabled={createCarMutation.isPending}
                      className="min-w-[120px]"
                    >
                      {createCarMutation.isPending ? (
                        <div className="flex items-center space-x-2">
                          <div className="spinner"></div>
                          <span>جاري النشر...</span>
                        </div>
                      ) : (
                        "نشر الإعلان"
                      )}
                    </Button>
                  )}
                </div>
              </div>
            </form>
          </Form>
        </motion.div>

        {/* Help Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-8"
        >
          <Card className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
            <CardContent className="p-6">
              <div className="flex items-start space-x-3">
                <AlertCircle className="h-6 w-6 text-blue-600 mt-1" />
                <div>
                  <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">
                    نصائح لإعلان ناجح
                  </h4>
                  <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
                    <li>• أضف صور واضحة ومتعددة للسيارة من جميع الزوايا</li>
                    <li>• اكتب عنوان واضح ووصف تفصيلي للسيارة</li>
                    <li>• حدد السعر بشكل واقعي ومنافس</li>
                    <li>• تأكد من صحة جميع المعلومات المدخلة</li>
                    <li>• سيتم مراجعة الإعلان خلال 24 ساعة</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
