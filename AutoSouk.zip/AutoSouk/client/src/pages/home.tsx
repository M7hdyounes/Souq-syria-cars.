import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/components/language-provider";
import { motion } from "framer-motion";
import { 
  Search, Star, MapPin, Eye, Heart, MessageCircle, Shield, 
  SearchIcon, Plus, Camera, TrendingUp, Users, Car, Truck, 
  CarTaxiFront, CarIcon, TicketSlash, TruckIcon
} from "lucide-react";
import CarCard from "@/components/car-card";
import { CAR_BRANDS, CAR_BODY_TYPES, SYRIAN_CITIES } from "@/lib/constants";

export default function Home() {
  const { t, language, isRTL } = useLanguage();
  const [searchFilters, setSearchFilters] = useState({
    bodyType: "",
    brand: "",
    city: ""
  });

  // Fetch featured cars
  const { data: featuredCars = [] } = useQuery({
    queryKey: ['/api/cars/featured'],
  });

  // Fetch featured dealerships
  const { data: featuredDealerships = [] } = useQuery({
    queryKey: ['/api/dealerships/featured'],
  });

  const categories = [
    { name: "سيدان", nameEn: "Sedan", icon: Car, count: "1,234" },
    { name: "دفع رباعي", nameEn: "SUV", icon: Truck, count: "892" },
    { name: "هاتشباك", nameEn: "Hatchback", icon: CarTaxiFront, count: "567" },
    { name: "كوبيه", nameEn: "Coupe", icon: CarIcon, count: "234" },
    { name: "فان", nameEn: "Van", icon: TicketSlash, count: "345" },
    { name: "بيك آب", nameEn: "Pickup", icon: TruckIcon, count: "156" },
  ];

  const stats = [
    { value: "25,000+", label: t("home.stats.cars"), labelEn: "Cars Listed" },
    { value: "500+", label: t("home.stats.dealers"), labelEn: "Dealers" },
    { value: "100,000+", label: t("home.stats.users"), labelEn: "Active Users" },
  ];

  const trustFeatures = [
    {
      icon: Shield,
      title: "أمان وحماية",
      titleEn: "Safety & Security",
      description: "جميع المعاملات محمية ومضمونة مع نظام تقييم للبائعين",
      descriptionEn: "All transactions are protected with seller rating system"
    },
    {
      icon: SearchIcon,
      title: "بحث متقدم",
      titleEn: "Advanced Search",
      description: "نظام بحث ذكي مع فلاتر متقدمة للعثور على السيارة المثالية",
      descriptionEn: "Smart search system with advanced filters"
    },
    {
      icon: MessageCircle,
      title: "تواصل مباشر",
      titleEn: "Direct Communication",
      description: "محادثة فورية مع البائعين وإمكانية التفاوض على الأسعار",
      descriptionEn: "Instant messaging with sellers and price negotiation"
    }
  ];

  const ctaFeatures = [
    {
      icon: Camera,
      title: "تصوير احترافي",
      titleEn: "Professional Photography",
      description: "ارفع صور عالية الجودة لسيارتك",
      descriptionEn: "Upload high-quality photos of your car"
    },
    {
      icon: TrendingUp,
      title: "إحصائيات مفصلة",
      titleEn: "Detailed Analytics",
      description: "تتبع مشاهدات إعلانك واهتمام المشترين",
      descriptionEn: "Track your listing views and buyer interest"
    },
    {
      icon: Users,
      title: "دعم كامل",
      titleEn: "Full Support",
      description: "فريق دعم يساعدك في كل خطوة",
      descriptionEn: "Support team to help you every step"
    }
  ];

  const handleSearch = () => {
    const queryParams = new URLSearchParams();
    if (searchFilters.bodyType) queryParams.set('bodyType', searchFilters.bodyType);
    if (searchFilters.brand) queryParams.set('brand', searchFilters.brand);
    if (searchFilters.city) queryParams.set('city', searchFilters.city);
    
    window.location.href = `/cars?${queryParams.toString()}`;
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative hero-section text-white">
        <div className="absolute inset-0 bg-black bg-opacity-40"></div>
        <div className="absolute inset-0 automotive-gradient opacity-90"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-shadow">
              {t("home.hero.title")}
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-200">
              {t("home.hero.subtitle")}
            </p>

            {/* Search Bar */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="max-w-4xl mx-auto bg-white rounded-2xl shadow-2xl p-6 mb-8"
            >
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="relative">
                  <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                    {t("home.search.type")}
                  </label>
                  <Select value={searchFilters.bodyType} onValueChange={(value) => 
                    setSearchFilters(prev => ({ ...prev, bodyType: value }))
                  }>
                    <SelectTrigger className="search-input text-gray-900">
                      <SelectValue placeholder="جميع الأنواع" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">جميع الأنواع</SelectItem>
                      {CAR_BODY_TYPES.map(type => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="relative">
                  <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                    {t("home.search.brand")}
                  </label>
                  <Select value={searchFilters.brand} onValueChange={(value) => 
                    setSearchFilters(prev => ({ ...prev, brand: value }))
                  }>
                    <SelectTrigger className="search-input text-gray-900">
                      <SelectValue placeholder="جميع الماركات" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">جميع الماركات</SelectItem>
                      {CAR_BRANDS.map(brand => (
                        <SelectItem key={brand} value={brand}>{brand}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="relative">
                  <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                    {t("home.search.city")}
                  </label>
                  <Select value={searchFilters.city} onValueChange={(value) => 
                    setSearchFilters(prev => ({ ...prev, city: value }))
                  }>
                    <SelectTrigger className="search-input text-gray-900">
                      <SelectValue placeholder="جميع المحافظات" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">جميع المحافظات</SelectItem>
                      {SYRIAN_CITIES.map(city => (
                        <SelectItem key={city} value={city}>{city}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-end">
                  <Button 
                    onClick={handleSearch}
                    className="w-full btn-primary"
                  >
                    <Search className="h-4 w-4 mr-2" />
                    {t("home.search.button")}
                  </Button>
                </div>
              </div>
            </motion.div>

            {/* Stats */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto"
            >
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-3xl font-bold mb-2">{stat.value}</div>
                  <div className="text-gray-200">
                    {language === "ar" ? stat.label : stat.labelEn}
                  </div>
                </div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Featured Cars Section */}
      <section className="py-16 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              {t("home.featured.title")}
            </h2>
            <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              {t("home.featured.subtitle")}
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {featuredCars.map((car, index) => (
              <motion.div
                key={car.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <CarCard car={car} />
              </motion.div>
            ))}
          </div>

          <div className="text-center">
            <Button variant="outline" size="lg" asChild>
              <Link href="/cars">
                {t("btn.viewAllCars")}
                <span className={`ml-2 ${isRTL ? 'rtl-flip' : ''}`}>←</span>
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              {t("home.categories.title")}
            </h2>
            <p className="text-gray-600 dark:text-gray-300">
              {t("home.categories.subtitle")}
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {categories.map((category, index) => {
              const IconComponent = category.icon;
              return (
                <motion.div
                  key={category.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Link href={`/cars?bodyType=${encodeURIComponent(category.name)}`}>
                    <Card className="bg-white dark:bg-gray-700 rounded-xl p-6 text-center hover:shadow-lg transition-all cursor-pointer group">
                      <CardContent className="p-0">
                        <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
                          <IconComponent className="h-8 w-8 text-primary" />
                        </div>
                        <h3 className="font-semibold text-gray-900 dark:text-white mb-1">
                          {language === "ar" ? category.name : category.nameEn}
                        </h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          {category.count} {language === "ar" ? "سيارة" : "cars"}
                        </p>
                      </CardContent>
                    </Card>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Featured Dealerships */}
      <section className="py-16 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              {t("home.dealerships.title")}
            </h2>
            <p className="text-gray-600 dark:text-gray-300">
              {t("home.dealerships.subtitle")}
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredDealerships.map((dealership, index) => (
              <motion.div
                key={dealership.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 text-center hover:shadow-xl transition-shadow">
                  <CardContent className="p-0">
                    <Avatar className="w-20 h-20 mx-auto mb-4">
                      <AvatarImage src={dealership.logo || ""} />
                      <AvatarFallback className="text-lg font-bold">
                        {dealership.name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    
                    <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                      {dealership.name}
                    </h3>
                    
                    <div className="flex justify-center items-center mb-2">
                      <div className="flex text-yellow-400 text-sm">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`h-4 w-4 ${i < Math.floor(parseFloat(dealership.rating || "0")) ? 'fill-current' : ''}`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-gray-500 dark:text-gray-400 mr-2">
                        ({dealership.rating || "0"})
                      </span>
                    </div>
                    
                    <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
                      {dealership.city}
                    </p>
                    
                    <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                      {language === "ar" ? "سيارة متاحة" : "cars available"}
                    </div>
                    
                    <Button variant="outline" className="w-full" asChild>
                      <Link href={`/dealerships/${dealership.id}`}>
                        {language === "ar" ? "زيارة المعرض" : "Visit Dealership"}
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust & Features Section */}
      <section className="py-16 bg-primary/5 dark:bg-primary/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              {t("home.trust.title")}
            </h2>
            <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              {t("home.trust.subtitle")}
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {trustFeatures.map((feature, index) => {
              const IconComponent = feature.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.2 }}
                  className="text-center"
                >
                  <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                    {language === "ar" ? feature.title : feature.titleEn}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300">
                    {language === "ar" ? feature.description : feature.descriptionEn}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 automotive-gradient text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {t("home.cta.title")}
            </h2>
            <p className="text-xl mb-8 text-primary-100">
              {t("home.cta.subtitle")}
            </p>
            
            <div className={`flex flex-col sm:flex-row gap-4 justify-center mb-12`}>
              <Button size="lg" variant="secondary" asChild>
                <Link href="/add-car">
                  <Plus className="h-5 w-5 mr-2" />
                  {language === "ar" ? "أضف إعلان مجاناً" : "Add Free Listing"}
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
                {language === "ar" ? "تعرف على المزايا" : "Learn More"}
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              {ctaFeatures.map((feature, index) => {
                const IconComponent = feature.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <IconComponent className="h-12 w-12 mx-auto mb-3 text-primary-200" />
                    <h4 className="font-semibold mb-2">
                      {language === "ar" ? feature.title : feature.titleEn}
                    </h4>
                    <p className="text-primary-100 text-sm">
                      {language === "ar" ? feature.description : feature.descriptionEn}
                    </p>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
