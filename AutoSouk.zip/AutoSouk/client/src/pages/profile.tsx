import { useState } from "react";
import { Link } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/components/language-provider";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import CarCard from "@/components/car-card";
import { motion } from "framer-motion";
import { 
  User, Edit, Car, Heart, MessageCircle, Star, 
  Calendar, MapPin, Phone, Mail, Settings, 
  Eye, TrendingUp, Plus, Trash2
} from "lucide-react";

export default function Profile() {
  const { user, logout } = useAuth();
  const { t, language } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editProfile, setEditProfile] = useState(false);
  const [profileData, setProfileData] = useState({
    firstName: user?.firstName || "",
    lastName: user?.lastName || "",
    phone: user?.phone || "",
    email: user?.email || "",
  });

  // Fetch user's cars
  const { data: userCars = [], isLoading: carsLoading } = useQuery({
    queryKey: ['/api/users', user?.id, 'cars'],
    enabled: !!user,
  });

  // Fetch user's favorites
  const { data: favorites = [], isLoading: favoritesLoading } = useQuery({
    queryKey: ['/api/users', user?.id, 'favorites'],
    enabled: !!user,
  });

  // Fetch user's messages
  const { data: messages = [], isLoading: messagesLoading } = useQuery({
    queryKey: ['/api/messages', user?.id],
    enabled: !!user,
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: typeof profileData) => {
      if (!user) throw new Error("User not found");
      return apiRequest("PUT", `/api/users/${user.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "تم التحديث",
        description: "تم تحديث الملف الشخصي بنجاح"
      });
      setEditProfile(false);
    },
    onError: (error: any) => {
      toast({
        title: "خطأ",
        description: error.message || "حدث خطأ أثناء التحديث",
        variant: "destructive"
      });
    }
  });

  const deleteCarMutation = useMutation({
    mutationFn: async (carId: string) => {
      return apiRequest("DELETE", `/api/cars/${carId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users', user?.id, 'cars'] });
      toast({
        title: "تم الحذف",
        description: "تم حذف الإعلان بنجاح"
      });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ",
        description: error.message || "حدث خطأ أثناء الحذف",
        variant: "destructive"
      });
    }
  });

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Card className="p-8 text-center max-w-md mx-4">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            {language === "ar" ? "تسجيل الدخول مطلوب" : "Login Required"}
          </h2>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            {language === "ar" ? "يجب تسجيل الدخول لعرض الملف الشخصي" : "You need to login to view your profile"}
          </p>
          <Button asChild>
            <Link href="/auth/login">
              {language === "ar" ? "تسجيل الدخول" : "Login"}
            </Link>
          </Button>
        </Card>
      </div>
    );
  }

  const stats = [
    { label: "إعلاناتي", value: userCars.length, icon: Car },
    { label: "المفضلة", value: favorites.length, icon: Heart },
    { label: "الرسائل", value: messages.length, icon: MessageCircle },
    { label: "التقييم", value: "4.8", icon: Star },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Profile Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-start md:items-center space-y-4 md:space-y-0 md:space-x-6">
                <Avatar className="w-24 h-24">
                  <AvatarImage src={user.avatar || ""} />
                  <AvatarFallback className="text-2xl font-bold">
                    {user.firstName.charAt(0)}{user.lastName.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                
                <div className="flex-1">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                    <div>
                      <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                        {user.firstName} {user.lastName}
                      </h1>
                      <div className="flex items-center space-x-2 text-gray-500 dark:text-gray-400 mt-1">
                        <Calendar className="h-4 w-4" />
                        <span className="text-sm">
                          عضو منذ {new Date(user.createdAt!).getFullYear()}
                        </span>
                      </div>
                      {user.phone && (
                        <div className="flex items-center space-x-2 text-gray-500 dark:text-gray-400 mt-1">
                          <Phone className="h-4 w-4" />
                          <span className="text-sm">{user.phone}</span>
                        </div>
                      )}
                      <div className="flex items-center space-x-2 text-gray-500 dark:text-gray-400 mt-1">
                        <Mail className="h-4 w-4" />
                        <span className="text-sm">{user.email}</span>
                      </div>
                    </div>
                    
                    <div className="flex space-x-2 mt-4 md:mt-0">
                      <Dialog open={editProfile} onOpenChange={setEditProfile}>
                        <DialogTrigger asChild>
                          <Button variant="outline">
                            <Edit className="h-4 w-4 mr-2" />
                            تعديل الملف
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>تعديل الملف الشخصي</DialogTitle>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <Label htmlFor="firstName">الاسم الأول</Label>
                                <Input
                                  id="firstName"
                                  value={profileData.firstName}
                                  onChange={(e) => setProfileData(prev => ({
                                    ...prev,
                                    firstName: e.target.value
                                  }))}
                                />
                              </div>
                              <div>
                                <Label htmlFor="lastName">الاسم الأخير</Label>
                                <Input
                                  id="lastName"
                                  value={profileData.lastName}
                                  onChange={(e) => setProfileData(prev => ({
                                    ...prev,
                                    lastName: e.target.value
                                  }))}
                                />
                              </div>
                            </div>
                            <div>
                              <Label htmlFor="phone">رقم الهاتف</Label>
                              <Input
                                id="phone"
                                value={profileData.phone}
                                onChange={(e) => setProfileData(prev => ({
                                  ...prev,
                                  phone: e.target.value
                                }))}
                              />
                            </div>
                            <div>
                              <Label htmlFor="email">البريد الإلكتروني</Label>
                              <Input
                                id="email"
                                type="email"
                                value={profileData.email}
                                onChange={(e) => setProfileData(prev => ({
                                  ...prev,
                                  email: e.target.value
                                }))}
                              />
                            </div>
                            <div className="flex space-x-2 pt-4">
                              <Button
                                onClick={() => updateProfileMutation.mutate(profileData)}
                                disabled={updateProfileMutation.isPending}
                                className="flex-1"
                              >
                                حفظ التغييرات
                              </Button>
                              <Button
                                variant="outline"
                                onClick={() => setEditProfile(false)}
                              >
                                إلغاء
                              </Button>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                      
                      <Button variant="outline" onClick={logout}>
                        تسجيل الخروج
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                {stats.map((stat, index) => {
                  const IconComponent = stat.icon;
                  return (
                    <div key={index} className="text-center">
                      <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-2">
                        <IconComponent className="h-6 w-6 text-primary" />
                      </div>
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">
                        {stat.value}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {stat.label}
                      </p>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Content Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Tabs defaultValue="cars" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="cars">إعلاناتي ({userCars.length})</TabsTrigger>
              <TabsTrigger value="favorites">المفضلة ({favorites.length})</TabsTrigger>
              <TabsTrigger value="messages">الرسائل ({messages.length})</TabsTrigger>
            </TabsList>

            {/* My Cars */}
            <TabsContent value="cars" className="mt-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                  إعلاناتي
                </h2>
                <Button asChild>
                  <Link href="/add-car">
                    <Plus className="h-4 w-4 mr-2" />
                    إضافة إعلان جديد
                  </Link>
                </Button>
              </div>

              {carsLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="animate-pulse">
                      <div className="bg-gray-200 dark:bg-gray-700 rounded-2xl h-80"></div>
                    </div>
                  ))}
                </div>
              ) : userCars.length === 0 ? (
                <Card className="p-8 text-center">
                  <Car className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                    لا توجد إعلانات
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400 mb-4">
                    لم تقم بإضافة أي إعلانات سيارات بعد
                  </p>
                  <Button asChild>
                    <Link href="/add-car">
                      <Plus className="h-4 w-4 mr-2" />
                      أضف إعلان سيارة
                    </Link>
                  </Button>
                </Card>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {userCars.map((car) => (
                    <div key={car.id} className="relative">
                      <CarCard car={car} showSellerInfo={false} />
                      
                      {/* Car Status */}
                      <div className="absolute top-4 left-4">
                        {car.isApproved ? (
                          <Badge className="bg-green-500">منشور</Badge>
                        ) : (
                          <Badge variant="secondary">قيد المراجعة</Badge>
                        )}
                      </div>

                      {/* Actions */}
                      <div className="absolute top-4 right-16 flex space-x-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="bg-white/90 hover:bg-white"
                          asChild
                        >
                          <Link href={`/cars/${car.id}/edit`}>
                            <Edit className="h-4 w-4" />
                          </Link>
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="bg-white/90 hover:bg-white text-red-600"
                          onClick={() => {
                            if (confirm("هل أنت متأكد من حذف هذا الإعلان؟")) {
                              deleteCarMutation.mutate(car.id);
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>

                      {/* Stats */}
                      <div className="absolute bottom-16 left-4 bg-black/50 text-white px-2 py-1 rounded text-xs flex items-center space-x-1">
                        <Eye className="h-3 w-3" />
                        <span>{car.viewCount || 0}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </TabsContent>

            {/* Favorites */}
            <TabsContent value="favorites" className="mt-6">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">
                السيارات المفضلة
              </h2>

              {favoritesLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="animate-pulse">
                      <div className="bg-gray-200 dark:bg-gray-700 rounded-2xl h-80"></div>
                    </div>
                  ))}
                </div>
              ) : favorites.length === 0 ? (
                <Card className="p-8 text-center">
                  <Heart className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                    لا توجد سيارات مفضلة
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400 mb-4">
                    لم تقم بإضافة أي سيارات للمفضلة بعد
                  </p>
                  <Button asChild>
                    <Link href="/cars">
                      تصفح السيارات
                    </Link>
                  </Button>
                </Card>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {favorites.map((car) => (
                    <CarCard key={car.id} car={car} />
                  ))}
                </div>
              )}
            </TabsContent>

            {/* Messages */}
            <TabsContent value="messages" className="mt-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                  الرسائل
                </h2>
                <Button asChild>
                  <Link href="/chat">
                    <MessageCircle className="h-4 w-4 mr-2" />
                    فتح المحادثات
                  </Link>
                </Button>
              </div>

              {messagesLoading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="animate-pulse">
                      <div className="bg-gray-200 dark:bg-gray-700 rounded-lg h-16"></div>
                    </div>
                  ))}
                </div>
              ) : messages.length === 0 ? (
                <Card className="p-8 text-center">
                  <MessageCircle className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                    لا توجد رسائل
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400">
                    لم تتلق أي رسائل بعد
                  </p>
                </Card>
              ) : (
                <div className="space-y-4">
                  {messages.slice(0, 10).map((message) => (
                    <Card key={message.id} className="cursor-pointer hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-3">
                          <Avatar className="w-10 h-10">
                            <AvatarFallback>
                              {message.senderId.slice(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <p className="text-sm font-medium text-gray-900 dark:text-white">
                                {message.senderId === user.id ? "أنت" : "مستخدم"}
                              </p>
                              <p className="text-xs text-gray-500 dark:text-gray-400">
                                {new Date(message.createdAt!).toLocaleDateString('ar-SY')}
                              </p>
                            </div>
                            <p className="text-sm text-gray-600 dark:text-gray-300 truncate">
                              {message.content}
                            </p>
                            {!message.isRead && message.receiverId === user.id && (
                              <div className="w-2 h-2 bg-primary rounded-full mt-1"></div>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}
