import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/hooks/use-auth";
import { useWebSocket } from "@/hooks/use-websocket";
import { useLanguage } from "@/components/language-provider";
import { apiRequest } from "@/lib/queryClient";
import { motion } from "framer-motion";
import { 
  MessageCircle, Send, Search, MoreVertical, 
  Phone, Video, Info, Smile, Paperclip,
  Check, CheckCheck, Clock
} from "lucide-react";

interface Conversation {
  id: string;
  userId: string;
  userName: string;
  avatar?: string;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  isOnline: boolean;
  carId?: string;
  carTitle?: string;
}

export default function Chat() {
  const { user } = useAuth();
  const { language } = useLanguage();
  const queryClient = useQueryClient();
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [messageText, setMessageText] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Fetch user's conversations (mock data structure)
  const { data: conversations = [], isLoading: conversationsLoading } = useQuery({
    queryKey: ['/api/messages', user?.id],
    queryFn: async () => {
      const response = await fetch(`/api/messages/${user?.id}`);
      if (!response.ok) return [];
      const messages = await response.json();
      
      // Group messages into conversations (simplified)
      const conversationsMap = new Map();
      messages.forEach((message: any) => {
        const otherUserId = message.senderId === user?.id ? message.receiverId : message.senderId;
        
        if (!conversationsMap.has(otherUserId)) {
          conversationsMap.set(otherUserId, {
            id: otherUserId,
            userId: otherUserId,
            userName: `مستخدم ${otherUserId.slice(0, 8)}`,
            lastMessage: message.content,
            lastMessageTime: message.createdAt,
            unreadCount: message.receiverId === user?.id && !message.isRead ? 1 : 0,
            isOnline: Math.random() > 0.5,
            carId: message.carId,
            carTitle: message.carId ? "سيارة" : undefined,
          });
        }
      });
      
      return Array.from(conversationsMap.values());
    },
    enabled: !!user,
  });

  // Fetch messages for selected conversation
  const { data: messages = [] } = useQuery({
    queryKey: ['/api/conversations', user?.id, selectedConversation],
    queryFn: async () => {
      if (!selectedConversation || !user) return [];
      const response = await fetch(`/api/conversations/${user.id}/${selectedConversation}`);
      if (!response.ok) return [];
      return response.json();
    },
    enabled: !!selectedConversation && !!user,
  });

  // WebSocket for real-time messaging
  const { sendChatMessage, isConnected } = useWebSocket({
    onMessage: (data) => {
      if (data.type === 'new_message') {
        queryClient.invalidateQueries({ queryKey: ['/api/messages'] });
        queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
      }
    }
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      if (!selectedConversation || !user) throw new Error("No conversation selected");
      
      // Send via WebSocket if connected
      if (isConnected) {
        sendChatMessage(selectedConversation, content);
      } else {
        // Fallback to HTTP
        return apiRequest("POST", "/api/messages", {
          senderId: user.id,
          receiverId: selectedConversation,
          content
        });
      }
    },
    onSuccess: () => {
      setMessageText("");
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
      queryClient.invalidateQueries({ queryKey: ['/api/messages'] });
    }
  });

  const handleSendMessage = () => {
    if (messageText.trim() && selectedConversation) {
      sendMessageMutation.mutate(messageText.trim());
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const filteredConversations = conversations.filter(conv =>
    conv.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    conv.lastMessage.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const selectedConv = conversations.find(c => c.id === selectedConversation);

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Card className="p-8 text-center max-w-md mx-4">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            {language === "ar" ? "تسجيل الدخول مطلوب" : "Login Required"}
          </h2>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            {language === "ar" ? "يجب تسجيل الدخول لعرض الرسائل" : "You need to login to view messages"}
          </p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="h-[calc(100vh-120px)] flex rounded-lg overflow-hidden bg-white dark:bg-gray-800 shadow-lg"
        >
          {/* Conversations Sidebar */}
          <div className="w-80 border-r border-gray-200 dark:border-gray-700 flex flex-col">
            {/* Header */}
            <div className="p-4 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                {language === "ar" ? "المحادثات" : "Conversations"}
              </h2>
              
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder={language === "ar" ? "البحث في المحادثات..." : "Search conversations..."}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Conversations List */}
            <ScrollArea className="flex-1">
              {conversationsLoading ? (
                <div className="p-4 space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="animate-pulse">
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
                        <div className="flex-1 space-y-2">
                          <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                          <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : filteredConversations.length === 0 ? (
                <div className="p-8 text-center">
                  <MessageCircle className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                    {language === "ar" ? "لا توجد محادثات" : "No conversations"}
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400">
                    {language === "ar" ? "ابدأ بإرسال رسالة لأحد البائعين" : "Start by sending a message to a seller"}
                  </p>
                </div>
              ) : (
                <div className="p-2">
                  {filteredConversations.map((conversation, index) => (
                    <motion.div
                      key={conversation.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className={`p-3 rounded-lg cursor-pointer transition-colors ${
                        selectedConversation === conversation.id
                          ? 'bg-primary/10 border border-primary/20'
                          : 'hover:bg-gray-50 dark:hover:bg-gray-700'
                      }`}
                      onClick={() => setSelectedConversation(conversation.id)}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="relative">
                          <Avatar className="w-12 h-12">
                            <AvatarImage src={conversation.avatar} />
                            <AvatarFallback>
                              {conversation.userName.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                          {conversation.isOnline && (
                            <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
                          )}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium text-gray-900 dark:text-white truncate">
                              {conversation.userName}
                            </h4>
                            <span className="text-xs text-gray-500 dark:text-gray-400">
                              {new Date(conversation.lastMessageTime).toLocaleTimeString('ar-SY', {
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </span>
                          </div>
                          
                          {conversation.carTitle && (
                            <p className="text-xs text-primary mb-1">
                              {conversation.carTitle}
                            </p>
                          )}
                          
                          <div className="flex items-center justify-between">
                            <p className="text-sm text-gray-600 dark:text-gray-300 truncate">
                              {conversation.lastMessage}
                            </p>
                            {conversation.unreadCount > 0 && (
                              <Badge variant="destructive" className="ml-2 h-5 w-5 rounded-full p-0 text-xs">
                                {conversation.unreadCount}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </div>

          {/* Chat Area */}
          <div className="flex-1 flex flex-col">
            {selectedConversation ? (
              <>
                {/* Chat Header */}
                <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={selectedConv?.avatar} />
                        <AvatarFallback>
                          {selectedConv?.userName.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      {selectedConv?.isOnline && (
                        <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
                      )}
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 dark:text-white">
                        {selectedConv?.userName}
                      </h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {selectedConv?.isOnline ? "متصل الآن" : "غير متصل"}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="sm">
                      <Phone className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Video className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Info className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {/* Messages */}
                <ScrollArea className="flex-1 p-4">
                  <div className="space-y-4">
                    {messages.map((message: any, index: number) => {
                      const isOwn = message.senderId === user.id;
                      const showTime = index === 0 || 
                        new Date(message.createdAt).getTime() - new Date(messages[index - 1].createdAt).getTime() > 300000;
                      
                      return (
                        <motion.div
                          key={message.id}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.05 }}
                        >
                          {showTime && (
                            <div className="text-center">
                              <span className="text-xs text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-700 px-3 py-1 rounded-full">
                                {new Date(message.createdAt).toLocaleString('ar-SY')}
                              </span>
                            </div>
                          )}
                          
                          <div className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-2xl ${
                              isOwn 
                                ? 'bg-primary text-white rounded-br-sm' 
                                : 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white rounded-bl-sm'
                            }`}>
                              <p className="text-sm">{message.content}</p>
                              <div className={`flex items-center justify-end space-x-1 mt-1 ${
                                isOwn ? 'text-white/70' : 'text-gray-500 dark:text-gray-400'
                              }`}>
                                <span className="text-xs">
                                  {new Date(message.createdAt).toLocaleTimeString('ar-SY', {
                                    hour: '2-digit',
                                    minute: '2-digit'
                                  })}
                                </span>
                                {isOwn && (
                                  message.isRead ? (
                                    <CheckCheck className="h-3 w-3" />
                                  ) : (
                                    <Check className="h-3 w-3" />
                                  )
                                )}
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                    <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>

                {/* Message Input */}
                <div className="p-4 border-t border-gray-200 dark:border-gray-700">
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="sm">
                      <Paperclip className="h-4 w-4" />
                    </Button>
                    
                    <div className="flex-1 relative">
                      <Input
                        placeholder={language === "ar" ? "اكتب رسالة..." : "Type a message..."}
                        value={messageText}
                        onChange={(e) => setMessageText(e.target.value)}
                        onKeyPress={handleKeyPress}
                        className="pr-12"
                      />
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="absolute right-2 top-1/2 transform -translate-y-1/2"
                      >
                        <Smile className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <Button 
                      onClick={handleSendMessage}
                      disabled={!messageText.trim() || sendMessageMutation.isPending}
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  {!isConnected && (
                    <div className="flex items-center space-x-2 mt-2 text-yellow-600 dark:text-yellow-400">
                      <Clock className="h-4 w-4" />
                      <span className="text-sm">إعادة الاتصال...</span>
                    </div>
                  )}
                </div>
              </>
            ) : (
              /* No Conversation Selected */
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <MessageCircle className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                    {language === "ar" ? "اختر محادثة" : "Select a conversation"}
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400">
                    {language === "ar" ? "اختر محادثة من القائمة لبدء الدردشة" : "Choose a conversation from the list to start chatting"}
                  </p>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
