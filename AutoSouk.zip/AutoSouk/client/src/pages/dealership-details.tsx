import { useState } from "react";
import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { useLanguage } from "@/components/language-provider";
import CarCard from "@/components/car-card";
import { motion } from "framer-motion";
import { 
  MapPin, Star, Phone, Globe, Mail, Clock, 
  Shield, Award, TrendingUp, Car, Users, 
  Calendar, Eye, MessageCircle, ChevronLeft
} from "lucide-react";

export default function DealershipDetails() {
  const [, params] = useRoute("/dealerships/:id");
  const { language } = useLanguage();
  const [activeTab, setActiveTab] = useState("cars");

  const dealershipId = params?.id;

  // Fetch dealership details
  const { data: dealership, isLoading, error } = useQuery({
    queryKey: ['/api/dealerships', dealershipId],
    queryFn: async () => {
      const response = await fetch(`/api/dealerships/${dealershipId}`);
      if (!response.ok) throw new Error('Dealership not found');
      return response.json();
    },
    enabled: !!dealershipId,
  });

  // Fetch dealership cars
  const { data: cars = [] } = useQuery({
    queryKey: ['/api/dealerships', dealershipId, 'cars'],
    queryFn: async () => {
      const response = await fetch(`/api/dealerships/${dealershipId}/cars`);
      if (!response.ok) return [];
      return response.json();
    },
    enabled: !!dealershipId,
  });

  // Fetch dealership reviews
  const { data: reviews = [] } = useQuery({
    queryKey: ['/api/dealerships', dealershipId, 'reviews'],
    queryFn: async () => {
      const response = await fetch(`/api/dealerships/${dealershipId}/reviews`);
      if (!response.ok) return [];
      return response.json();
    },
    enabled: !!dealershipId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse space-y-8">
            <div className="bg-gray-200 dark:bg-gray-700 rounded-2xl h-64"></div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-4">
                <div className="bg-gray-200 dark:bg-gray-700 rounded h-8"></div>
                <div className="bg-gray-200 dark:bg-gray-700 rounded h-32"></div>
              </div>
              <div className="space-y-4">
                <div className="bg-gray-200 dark:bg-gray-700 rounded h-64"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !dealership) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Card className="p-8 text-center max-w-md mx-4">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            {language === "ar" ? "المعرض غير موجود" : "Dealership Not Found"}
          </h2>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            {language === "ar" ? "لم يتم العثور على المعرض المطلوب" : "The requested dealership was not found"}
          </p>
          <Button asChild>
            <Link href="/dealerships">
              {language === "ar" ? "تصفح المعارض" : "Browse Dealerships"}
            </Link>
          </Button>
        </Card>
      </div>
    );
  }

  const stats = [
    { label: "سيارة متاحة", value: cars.length, icon: Car },
    { label: "تقييم العملاء", value: dealership.reviewCount || 0, icon: Users },
    { label: "سنوات الخبرة", value: new Date().getFullYear() - new Date(dealership.createdAt!).getFullYear(), icon: Calendar },
    { label: "مشاهدات الملف", value: "2,543", icon: Eye },
  ];

  const trustFeatures = [
    {
      icon: Shield,
      title: "معرض موثق",
      description: "معتمد ومراجع من قبل إدارة الموقع",
      active: dealership.isVerified
    },
    {
      icon: Award,
      title: "تقييم ممتاز",
      description: `تقييم ${dealership.rating || "0"} من 5 نجوم`,
      active: parseFloat(dealership.rating || "0") >= 4.0
    },
    {
      icon: TrendingUp,
      title: "أداء متميز",
      description: "سجل حافل بالمبيعات الناجحة",
      active: true
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <nav className="flex items-center space-x-2 text-sm text-gray-500 dark:text-gray-400 mb-6">
          <Link href="/" className="hover:text-primary">الرئيسية</Link>
          <ChevronLeft className="h-4 w-4" />
          <Link href="/dealerships" className="hover:text-primary">المعارض</Link>
          <ChevronLeft className="h-4 w-4" />
          <span className="text-gray-900 dark:text-white">{dealership.name}</span>
        </nav>

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Card className="overflow-hidden">
            {/* Cover Image */}
            <div className="h-48 bg-gradient-to-r from-primary-600 to-primary-700 relative">
              {dealership.coverImage ? (
                <img 
                  src={dealership.coverImage} 
                  alt={dealership.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-gradient-to-r from-primary-600 to-primary-700"></div>
              )}
              <div className="absolute inset-0 bg-black/20"></div>
            </div>

            <CardContent className="p-6 relative">
              {/* Logo */}
              <div className="absolute -top-16 left-6">
                <Avatar className="w-24 h-24 border-4 border-white shadow-lg">
                  <AvatarImage src={dealership.logo || ""} />
                  <AvatarFallback className="text-2xl font-bold bg-white text-gray-900">
                    {dealership.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
              </div>

              <div className="pt-12">
                <div className="flex flex-col md:flex-row md:items-start md:justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                        {dealership.name}
                      </h1>
                      {dealership.isVerified && (
                        <Badge className="bg-green-500 text-white">
                          <Shield className="h-3 w-3 mr-1" />
                          موثق
                        </Badge>
                      )}
                    </div>

                    {/* Rating */}
                    <div className="flex items-center space-x-2 mb-3">
                      <div className="flex text-yellow-400">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`h-5 w-5 ${
                              i < Math.floor(parseFloat(dealership.rating || "0")) 
                                ? 'fill-current' 
                                : ''
                            }`}
                          />
                        ))}
                      </div>
                      <span className="font-semibold text-gray-900 dark:text-white">
                        {dealership.rating || "0"}
                      </span>
                      <span className="text-gray-500 dark:text-gray-400">
                        ({dealership.reviewCount || 0} تقييم)
                      </span>
                    </div>

                    {/* Location */}
                    {dealership.city && (
                      <div className="flex items-center space-x-2 text-gray-600 dark:text-gray-300 mb-4">
                        <MapPin className="h-4 w-4" />
                        <span>{dealership.address ? `${dealership.address}, ` : ""}{dealership.city}</span>
                      </div>
                    )}

                    {/* Description */}
                    {dealership.description && (
                      <p className="text-gray-600 dark:text-gray-300 max-w-2xl">
                        {dealership.description}
                      </p>
                    )}
                  </div>

                  {/* Contact Actions */}
                  <div className="flex flex-col space-y-2 mt-4 md:mt-0 md:ml-6">
                    {dealership.phone && (
                      <Button className="min-w-[140px]">
                        <Phone className="h-4 w-4 mr-2" />
                        اتصال
                      </Button>
                    )}
                    <Button variant="outline">
                      <MessageCircle className="h-4 w-4 mr-2" />
                      رسالة
                    </Button>
                    {dealership.website && (
                      <Button variant="outline" asChild>
                        <a href={dealership.website} target="_blank" rel="noopener noreferrer">
                          <Globe className="h-4 w-4 mr-2" />
                          الموقع
                        </a>
                      </Button>
                    )}
                  </div>
                </div>

                {/* Stats */}
                <Separator className="my-6" />
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {stats.map((stat, index) => {
                    const IconComponent = stat.icon;
                    return (
                      <div key={index} className="text-center">
                        <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-2">
                          <IconComponent className="h-6 w-6 text-primary" />
                        </div>
                        <p className="text-xl font-bold text-gray-900 dark:text-white">
                          {stat.value}
                        </p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          {stat.label}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="cars">السيارات ({cars.length})</TabsTrigger>
                  <TabsTrigger value="about">نبذة عن المعرض</TabsTrigger>
                  <TabsTrigger value="reviews">التقييمات ({reviews.length})</TabsTrigger>
                </TabsList>

                {/* Cars Tab */}
                <TabsContent value="cars" className="mt-6">
                  {cars.length === 0 ? (
                    <Card className="p-8 text-center">
                      <Car className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                        لا توجد سيارات متاحة
                      </h3>
                      <p className="text-gray-500 dark:text-gray-400">
                        هذا المعرض لا يحتوي على سيارات معروضة حالياً
                      </p>
                    </Card>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {cars.map((car, index) => (
                        <motion.div
                          key={car.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.1 }}
                        >
                          <CarCard car={car} showSellerInfo={false} />
                        </motion.div>
                      ))}
                    </div>
                  )}
                </TabsContent>

                {/* About Tab */}
                <TabsContent value="about" className="mt-6">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="text-xl font-semibold mb-4">نبذة عن المعرض</h3>
                      
                      {dealership.description ? (
                        <div className="space-y-4">
                          <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                            {dealership.description}
                          </p>
                          
                          <Separator />
                          
                          {/* Contact Information */}
                          <div>
                            <h4 className="font-semibold mb-3">معلومات الاتصال</h4>
                            <div className="space-y-2">
                              {dealership.phone && (
                                <div className="flex items-center space-x-3">
                                  <Phone className="h-4 w-4 text-gray-400" />
                                  <span className="text-gray-600 dark:text-gray-300">{dealership.phone}</span>
                                </div>
                              )}
                              {dealership.email && (
                                <div className="flex items-center space-x-3">
                                  <Mail className="h-4 w-4 text-gray-400" />
                                  <span className="text-gray-600 dark:text-gray-300">{dealership.email}</span>
                                </div>
                              )}
                              {dealership.website && (
                                <div className="flex items-center space-x-3">
                                  <Globe className="h-4 w-4 text-gray-400" />
                                  <a 
                                    href={dealership.website} 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="text-primary hover:underline"
                                  >
                                    {dealership.website}
                                  </a>
                                </div>
                              )}
                              <div className="flex items-center space-x-3">
                                <Clock className="h-4 w-4 text-gray-400" />
                                <span className="text-gray-600 dark:text-gray-300">
                                  السبت - الخميس: 9:00 ص - 6:00 م
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <p className="text-gray-500 dark:text-gray-400 italic">
                          لم يتم إضافة وصف لهذا المعرض
                        </p>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Reviews Tab */}
                <TabsContent value="reviews" className="mt-6">
                  {reviews.length === 0 ? (
                    <Card className="p-8 text-center">
                      <Star className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                        لا توجد تقييمات
                      </h3>
                      <p className="text-gray-500 dark:text-gray-400">
                        لم يتم تقييم هذا المعرض بعد
                      </p>
                    </Card>
                  ) : (
                    <div className="space-y-6">
                      {reviews.map((review, index) => (
                        <motion.div
                          key={review.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.1 }}
                        >
                          <Card>
                            <CardContent className="p-6">
                              <div className="flex items-start space-x-4">
                                <Avatar className="w-10 h-10">
                                  <AvatarFallback>
                                    {review.reviewerId.slice(0, 2).toUpperCase()}
                                  </AvatarFallback>
                                </Avatar>
                                <div className="flex-1">
                                  <div className="flex items-center justify-between mb-2">
                                    <h4 className="font-medium text-gray-900 dark:text-white">
                                      مستخدم
                                    </h4>
                                    <span className="text-sm text-gray-500 dark:text-gray-400">
                                      {new Date(review.createdAt!).toLocaleDateString('ar-SY')}
                                    </span>
                                  </div>
                                  <div className="flex text-yellow-400 mb-2">
                                    {[...Array(5)].map((_, i) => (
                                      <Star 
                                        key={i} 
                                        className={`h-4 w-4 ${
                                          i < review.rating ? 'fill-current' : ''
                                        }`}
                                      />
                                    ))}
                                  </div>
                                  {review.comment && (
                                    <p className="text-gray-600 dark:text-gray-300">
                                      {review.comment}
                                    </p>
                                  )}
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Trust Indicators */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">مؤشرات الثقة</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {trustFeatures.map((feature, index) => {
                    const IconComponent = feature.icon;
                    return (
                      <div key={index} className="flex items-start space-x-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          feature.active 
                            ? 'bg-green-100 text-green-600' 
                            : 'bg-gray-100 text-gray-400'
                        }`}>
                          <IconComponent className="h-5 w-5" />
                        </div>
                        <div className="flex-1">
                          <h4 className={`font-medium ${
                            feature.active 
                              ? 'text-gray-900 dark:text-white' 
                              : 'text-gray-500 dark:text-gray-400'
                          }`}>
                            {feature.title}
                          </h4>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {feature.description}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            </motion.div>

            {/* Quick Stats */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">إحصائيات سريعة</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-300">عضو منذ</span>
                    <span className="font-semibold">
                      {new Date(dealership.createdAt!).getFullYear()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-300">إجمالي السيارات</span>
                    <span className="font-semibold">{cars.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-300">متوسط التقييم</span>
                    <span className="font-semibold">{dealership.rating || "0"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-300">عدد التقييمات</span>
                    <span className="font-semibold">{dealership.reviewCount || 0}</span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Contact Card */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">تواصل مع المعرض</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {dealership.phone && (
                    <Button className="w-full">
                      <Phone className="h-4 w-4 mr-2" />
                      {dealership.phone}
                    </Button>
                  )}
                  <Button variant="outline" className="w-full">
                    <MessageCircle className="h-4 w-4 mr-2" />
                    إرسال رسالة
                  </Button>
                  {dealership.email && (
                    <Button variant="outline" className="w-full" asChild>
                      <a href={`mailto:${dealership.email}`}>
                        <Mail className="h-4 w-4 mr-2" />
                        إرسال إيميل
                      </a>
                    </Button>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
