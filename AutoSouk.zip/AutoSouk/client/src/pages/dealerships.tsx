import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useLanguage } from "@/components/language-provider";
import { motion } from "framer-motion";
import { 
  Search, MapPin, Star, Car, Phone, Globe, 
  Award, Shield, TrendingUp, Filter, X
} from "lucide-react";
import { SYRIAN_CITIES } from "@/lib/constants";

export default function Dealerships() {
  const { t, language } = useLanguage();
  const [filters, setFilters] = useState({
    search: "",
    city: "",
    verified: false,
  });

  const { data: dealerships = [], isLoading, error } = useQuery({
    queryKey: ['/api/dealerships', filters],
    queryFn: async () => {
      const params = new URLSearchParams();
      
      Object.entries(filters).forEach(([key, value]) => {
        if (value && value !== "") {
          params.set(key, value.toString());
        }
      });

      const response = await fetch(`/api/dealerships?${params.toString()}`);
      if (!response.ok) throw new Error('Failed to fetch dealerships');
      return response.json();
    },
  });

  const { data: featuredDealerships = [] } = useQuery({
    queryKey: ['/api/dealerships/featured'],
  });

  const updateFilters = (newFilters: Partial<typeof filters>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  };

  const clearFilters = () => {
    setFilters({
      search: "",
      city: "",
      verified: false,
    });
  };

  const trustBadges = [
    { icon: Shield, label: "موثق", color: "bg-green-100 text-green-800" },
    { icon: Award, label: "متميز", color: "bg-blue-100 text-blue-800" },
    { icon: TrendingUp, label: "أداء ممتاز", color: "bg-purple-100 text-purple-800" },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            {language === "ar" ? "المعارض الموثوقة" : "Trusted Dealerships"}
          </h1>
          <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            {language === "ar" 
              ? "تعامل مع أفضل المعارض المعتمدة في سوريا واحصل على أفضل العروض"
              : "Deal with the best certified dealers in Syria and get the best offers"
            }
          </p>
        </motion.div>

        {/* Search and Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <Card>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="md:col-span-2 relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder={language === "ar" ? "ابحث عن معرض..." : "Search for dealership..."}
                    value={filters.search}
                    onChange={(e) => updateFilters({ search: e.target.value })}
                    className="pl-10"
                  />
                </div>
                
                <Select value={filters.city} onValueChange={(value) => updateFilters({ city: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder={language === "ar" ? "المدينة" : "City"} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">{language === "ar" ? "جميع المدن" : "All cities"}</SelectItem>
                    {SYRIAN_CITIES.map(city => (
                      <SelectItem key={city} value={city}>{city}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <div className="flex space-x-2">
                  <Button
                    variant={filters.verified ? "default" : "outline"}
                    onClick={() => updateFilters({ verified: !filters.verified })}
                    className="flex-1"
                  >
                    <Shield className="h-4 w-4 mr-2" />
                    موثق فقط
                  </Button>
                  
                  {(filters.search || filters.city || filters.verified) && (
                    <Button variant="ghost" onClick={clearFilters}>
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Featured Dealerships */}
        {featuredDealerships.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mb-12"
          >
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
              {language === "ar" ? "المعارض المميزة" : "Featured Dealerships"}
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredDealerships.map((dealership, index) => (
                <motion.div
                  key={dealership.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="relative overflow-hidden hover:shadow-xl transition-all duration-300 group">
                    {/* Featured Badge */}
                    <div className="absolute top-4 right-4 z-10">
                      <Badge className="bg-primary text-white">
                        {language === "ar" ? "مميز" : "Featured"}
                      </Badge>
                    </div>

                    {/* Cover Image */}
                    <div className="h-32 bg-gradient-to-r from-primary-600 to-primary-700 relative">
                      {dealership.coverImage ? (
                        <img 
                          src={dealership.coverImage} 
                          alt={dealership.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-r from-primary-600 to-primary-700"></div>
                      )}
                      <div className="absolute inset-0 bg-black/20"></div>
                    </div>

                    <CardContent className="p-6 relative">
                      {/* Logo */}
                      <div className="absolute -top-8 left-6">
                        <Avatar className="w-16 h-16 border-4 border-white shadow-lg">
                          <AvatarImage src={dealership.logo || ""} />
                          <AvatarFallback className="text-lg font-bold bg-white">
                            {dealership.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                      </div>

                      <div className="pt-10">
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                            {dealership.name}
                          </h3>
                          {dealership.isVerified && (
                            <Shield className="h-5 w-5 text-green-600" />
                          )}
                        </div>

                        {/* Rating */}
                        <div className="flex items-center space-x-1 mb-3">
                          <div className="flex text-yellow-400">
                            {[...Array(5)].map((_, i) => (
                              <Star 
                                key={i} 
                                className={`h-4 w-4 ${
                                  i < Math.floor(parseFloat(dealership.rating || "0")) 
                                    ? 'fill-current' 
                                    : ''
                                }`}
                              />
                            ))}
                          </div>
                          <span className="text-sm text-gray-500 dark:text-gray-400">
                            ({dealership.rating || "0"})
                          </span>
                          <span className="text-sm text-gray-400">•</span>
                          <span className="text-sm text-gray-500 dark:text-gray-400">
                            {dealership.reviewCount || 0} تقييم
                          </span>
                        </div>

                        {/* Location */}
                        {dealership.city && (
                          <div className="flex items-center space-x-1 text-gray-500 dark:text-gray-400 mb-3">
                            <MapPin className="h-4 w-4" />
                            <span className="text-sm">{dealership.city}</span>
                          </div>
                        )}

                        {/* Trust Badges */}
                        <div className="flex space-x-2 mb-4">
                          {dealership.isVerified && (
                            <div className="flex items-center space-x-1 px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">
                              <Shield className="h-3 w-3" />
                              <span>موثق</span>
                            </div>
                          )}
                          {parseFloat(dealership.rating || "0") >= 4.5 && (
                            <div className="flex items-center space-x-1 px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs">
                              <Award className="h-3 w-3" />
                              <span>متميز</span>
                            </div>
                          )}
                        </div>

                        {/* Stats */}
                        <div className="grid grid-cols-2 gap-4 mb-4 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                          <div className="text-center">
                            <p className="text-lg font-semibold text-gray-900 dark:text-white">
                              {Math.floor(Math.random() * 100) + 50}
                            </p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">
                              سيارة متاحة
                            </p>
                          </div>
                          <div className="text-center">
                            <p className="text-lg font-semibold text-gray-900 dark:text-white">
                              {dealership.reviewCount || 0}
                            </p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">
                              عملية بيع
                            </p>
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex space-x-2">
                          <Button className="flex-1" asChild>
                            <Link href={`/dealerships/${dealership.id}`}>
                              زيارة المعرض
                            </Link>
                          </Button>
                          {dealership.phone && (
                            <Button variant="outline" size="sm">
                              <Phone className="h-4 w-4" />
                            </Button>
                          )}
                          {dealership.website && (
                            <Button variant="outline" size="sm">
                              <Globe className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* All Dealerships */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
              {language === "ar" ? "جميع المعارض" : "All Dealerships"}
            </h2>
            <p className="text-gray-600 dark:text-gray-300">
              {dealerships.length} {language === "ar" ? "معرض" : "dealerships"}
            </p>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(9)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-gray-200 dark:bg-gray-700 rounded-2xl h-64"></div>
                </div>
              ))}
            </div>
          ) : error ? (
            <Card className="p-8 text-center">
              <p className="text-gray-500 dark:text-gray-400">
                {language === "ar" ? "حدث خطأ في تحميل المعارض" : "Error loading dealerships"}
              </p>
            </Card>
          ) : dealerships.length === 0 ? (
            <Card className="p-8 text-center">
              <Car className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                {language === "ar" ? "لا توجد معارض" : "No dealerships found"}
              </h3>
              <p className="text-gray-500 dark:text-gray-400">
                {language === "ar" ? "لا توجد معارض تطابق البحث" : "No dealerships match your search"}
              </p>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {dealerships.map((dealership, index) => (
                <motion.div
                  key={dealership.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="hover:shadow-lg transition-shadow duration-300">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4 mb-4">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={dealership.logo || ""} />
                          <AvatarFallback className="font-bold">
                            {dealership.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2">
                            <h3 className="font-semibold text-gray-900 dark:text-white truncate">
                              {dealership.name}
                            </h3>
                            {dealership.isVerified && (
                              <Shield className="h-4 w-4 text-green-600 flex-shrink-0" />
                            )}
                          </div>
                          
                          <div className="flex items-center space-x-1 mt-1">
                            <div className="flex text-yellow-400 text-sm">
                              {[...Array(5)].map((_, i) => (
                                <Star 
                                  key={i} 
                                  className={`h-3 w-3 ${
                                    i < Math.floor(parseFloat(dealership.rating || "0")) 
                                      ? 'fill-current' 
                                      : ''
                                  }`}
                                />
                              ))}
                            </div>
                            <span className="text-xs text-gray-500 dark:text-gray-400">
                              ({dealership.rating || "0"})
                            </span>
                          </div>
                          
                          {dealership.city && (
                            <div className="flex items-center space-x-1 text-gray-500 dark:text-gray-400 mt-1">
                              <MapPin className="h-3 w-3" />
                              <span className="text-xs">{dealership.city}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {dealership.description && (
                        <p className="text-sm text-gray-600 dark:text-gray-300 mb-4 line-clamp-2">
                          {dealership.description}
                        </p>
                      )}

                      <div className="flex justify-between items-center">
                        <div className="text-sm text-gray-500 dark:text-gray-400">
                          {Math.floor(Math.random() * 100) + 20} سيارة متاحة
                        </div>
                        
                        <Button size="sm" asChild>
                          <Link href={`/dealerships/${dealership.id}`}>
                            زيارة
                          </Link>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>

        {/* Trust Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-16"
        >
          <Card className="bg-primary/5 dark:bg-primary/10 border-primary/20">
            <CardContent className="p-8 text-center">
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                {language === "ar" ? "لماذا تختار معارضنا الموثوقة؟" : "Why Choose Our Trusted Dealerships?"}
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
                {trustBadges.map((badge, index) => {
                  const IconComponent = badge.icon;
                  return (
                    <div key={index} className="text-center">
                      <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                        <IconComponent className="h-8 w-8 text-primary" />
                      </div>
                      <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                        {badge.label}
                      </h4>
                      <p className="text-sm text-gray-600 dark:text-gray-300">
                        {badge.label === "موثق" && "جميع معارضنا مراجعة ومعتمدة"}
                        {badge.label === "متميز" && "أفضل الخدمات وأعلى التقييمات"}
                        {badge.label === "أداء ممتاز" && "سجل حافل بالمبيعات الناجحة"}
                      </p>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
