export const CAR_BRANDS = [
  "تويوتا", "هيونداي", "نيسان", "كيا", "شيفروليه", "فورد", "فولكس واجن", 
  "بيجو", "رينو", "مازدا", "سوزوكي", "سوبارو", "هوندا", "ميتسوبيشي", "فيات"
];

export const CAR_BODY_TYPES = [
  "سيدان", "هاتشباك", "دفع رباعي", "كوبيه", "كابريوليه", "فان", "بيك آب", "باص"
];

export const FUEL_TYPES = [
  "بنزين", "ديزل", "غاز", "هجين", "كهربائي"
];

export const TRANSMISSION_TYPES = [
  "أوتوماتيك", "مانيوال", "نصف أوتوماتيك"
];

export const CAR_CONDITIONS = [
  "جديد", "مستعمل - ممتاز", "مستعمل - جيد جداً", "مستعمل - جيد", "مستعمل - متوسط", "يحتاج صيانة"
];

export const SYRIAN_CITIES = [
  "دمشق", "حلب", "حمص", "حماه", "اللاذقية", "دير الزور", "الرقة", "إدلب", 
  "درعا", "السويداء", "القنيطرة", "طرطوس", "الحسكة", "القامشلي"
];

export const LANGUAGES = {
  ar: "العربية",
  en: "English"
};

export const THEMES = {
  light: "فاتح",
  dark: "داكن",
  system: "تلقائي"
};

export const ADMIN_CREDENTIALS = {
  email: "my3450589@gmail.com",
  password: "12345678mhd9"
};

export const PAGINATION_LIMITS = {
  cars: 12,
  messages: 50,
  reviews: 10
};

export const WEBSOCKET_EVENTS = {
  CHAT_MESSAGE: "chat_message",
  NEW_MESSAGE: "new_message",
  USER_ONLINE: "user_online",
  USER_OFFLINE: "user_offline"
};

export const API_ENDPOINTS = {
  // Auth
  REGISTER: "/api/auth/register",
  LOGIN: "/api/auth/login",
  ADMIN_LOGIN: "/api/admin/login",
  
  // Cars
  CARS: "/api/cars",
  FEATURED_CARS: "/api/cars/featured",
  USER_CARS: (userId: string) => `/api/users/${userId}/cars`,
  
  // Favorites
  FAVORITES: "/api/favorites",
  USER_FAVORITES: (userId: string) => `/api/users/${userId}/favorites`,
  
  // Dealerships
  DEALERSHIPS: "/api/dealerships",
  FEATURED_DEALERSHIPS: "/api/dealerships/featured",
  DEALERSHIP_CARS: (id: string) => `/api/dealerships/${id}/cars`,
  
  // Messages
  MESSAGES: "/api/messages",
  USER_MESSAGES: (userId: string) => `/api/messages/${userId}`,
  CONVERSATION: (userId1: string, userId2: string) => `/api/conversations/${userId1}/${userId2}`,
  
  // Reviews
  REVIEWS: "/api/reviews",
  USER_REVIEWS: (userId: string) => `/api/users/${userId}/reviews`,
  
  // Complaints
  COMPLAINTS: "/api/complaints",
  
  // Admin
  ADMIN_STATS: "/api/admin/stats",
  ADMIN_COMPLAINTS: "/api/admin/complaints",
  ADMIN_CARS: "/api/admin/cars",
  APPROVE_CAR: (id: string) => `/api/admin/cars/${id}/approve`
};

export const FILE_UPLOAD_LIMITS = {
  maxSize: 5 * 1024 * 1024, // 5MB
  allowedTypes: ["image/jpeg", "image/png", "image/webp"],
  maxFiles: 10
};

export const VALIDATION_RULES = {
  password: {
    minLength: 8,
    requireUppercase: false,
    requireLowercase: false,
    requireNumbers: true,
    requireSpecialChars: false
  },
  phone: {
    pattern: /^[0-9]{10}$/,
    message: "رقم الهاتف يجب أن يكون 10 أرقام"
  },
  email: {
    pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    message: "البريد الإلكتروني غير صحيح"
  }
};

export const SOCIAL_MEDIA_LINKS = {
  facebook: "https://facebook.com/souqsyriacars",
  telegram: "https://t.me/souqsyriacars", 
  whatsapp: "https://wa.me/963123456789",
  instagram: "https://instagram.com/souqsyriacars"
};

export const CONTACT_INFO = {
  phone: "+963 11 123 4567",
  email: "info@souqsyriacars.com",
  address: "دمشق، سوريا",
  workingHours: "السبت - الخميس: 9:00 ص - 6:00 م"
};
