import React, { createContext, useContext, useState, useEffect } from "react";
import { apiRequest } from "@/lib/queryClient";
import { User, Admin } from "@shared/schema";

interface AuthContextType {
  user: User | null;
  admin: Admin | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (userData: any) => Promise<void>;
  adminLogin: (email: string, password: string) => Promise<void>;
  logout: () => void;
  adminLogout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [admin, setAdmin] = useState<Admin | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for stored auth data
    const storedUser = localStorage.getItem("user");
    const storedAdmin = localStorage.getItem("admin");
    
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (error) {
        localStorage.removeItem("user");
      }
    }
    
    if (storedAdmin) {
      try {
        setAdmin(JSON.parse(storedAdmin));
      } catch (error) {
        localStorage.removeItem("admin");
      }
    }
    
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    const response = await apiRequest("POST", "/api/auth/login", { email, password });
    const { user } = await response.json();
    
    setUser(user);
    localStorage.setItem("user", JSON.stringify(user));
  };

  const register = async (userData: any) => {
    const response = await apiRequest("POST", "/api/auth/register", userData);
    const { user } = await response.json();
    
    setUser(user);
    localStorage.setItem("user", JSON.stringify(user));
  };

  const adminLogin = async (email: string, password: string) => {
    const response = await apiRequest("POST", "/api/admin/login", { email, password });
    const { admin } = await response.json();
    
    setAdmin(admin);
    localStorage.setItem("admin", JSON.stringify(admin));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("user");
  };

  const adminLogout = () => {
    setAdmin(null);
    localStorage.removeItem("admin");
  };

  return (
    <AuthContext.Provider value={{
      user,
      admin,
      isLoading,
      login,
      register,
      adminLogin,
      logout,
      adminLogout
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
