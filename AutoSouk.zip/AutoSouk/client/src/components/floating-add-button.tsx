import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/components/language-provider";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Plus, Car, Building2, MessageCircle, X, 
  ArrowRight, Zap, Star, Clock, Shield
} from "lucide-react";

export default function FloatingAddButton() {
  const { user } = useAuth();
  const { language } = useLanguage();
  const [isExpanded, setIsExpanded] = useState(false);
  const [showLoginPrompt, setShowLoginPrompt] = useState(false);

  const addOptions = [
    {
      icon: Car,
      title: "إضافة سيارة",
      titleEn: "Add Car",
      description: "أضف إعلان سيارة للبيع",
      descriptionEn: "Add a car listing for sale",
      href: "/add-car",
      color: "bg-blue-500 hover:bg-blue-600",
      featured: true
    },
    {
      icon: Building2,
      title: "إضافة معرض",
      titleEn: "Add Dealership", 
      description: "سجل معرضك التجاري",
      descriptionEn: "Register your dealership",
      href: "/add-dealership",
      color: "bg-purple-500 hover:bg-purple-600",
      featured: false
    },
    {
      icon: MessageCircle,
      title: "تقديم شكوى",
      titleEn: "Submit Complaint",
      description: "أرسل شكوى أو اقتراح",
      descriptionEn: "Send a complaint or suggestion",
      href: "/complaints",
      color: "bg-red-500 hover:bg-red-600",
      featured: false
    }
  ];

  const handleOptionClick = (href: string) => {
    if (!user) {
      setShowLoginPrompt(true);
      setIsExpanded(false);
      return;
    }
    
    // Navigate to the link
    window.location.href = href;
  };

  const benefits = [
    {
      icon: Zap,
      title: "سريع ومجاني",
      description: "أضف إعلانك في دقائق"
    },
    {
      icon: Star,
      title: "وصول أكبر",
      description: "آلاف المشترين يتصفحون يومياً"
    },
    {
      icon: Shield,
      title: "آمن وموثوق",
      description: "منصة محمية ومراجعة"
    }
  ];

  return (
    <>
      {/* Main Floating Button */}
      <motion.div
        className="fixed bottom-6 left-6 z-40"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <Button
          onClick={() => setIsExpanded(!isExpanded)}
          className="w-14 h-14 bg-primary hover:bg-primary/90 text-white rounded-full shadow-lg relative"
          title={language === "ar" ? "إضافة محتوى" : "Add Content"}
        >
          <AnimatePresence mode="wait">
            {isExpanded ? (
              <motion.div
                key="close"
                initial={{ rotate: -90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: 90, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <X className="h-6 w-6" />
              </motion.div>
            ) : (
              <motion.div
                key="plus"
                initial={{ rotate: 90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: -90, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <Plus className="h-6 w-6" />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Pulse Animation */}
          {!isExpanded && (
            <div className="absolute inset-0 rounded-full bg-primary animate-ping opacity-20"></div>
          )}
        </Button>
      </motion.div>

      {/* Expanded Options */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, x: 20, y: 20 }}
            animate={{ opacity: 1, scale: 1, x: 0, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, x: 20, y: 20 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="fixed bottom-24 left-6 z-40"
          >
            <Card className="shadow-2xl border-0 overflow-hidden w-72">
              <CardContent className="p-4">
                <h3 className="font-semibold text-gray-900 dark:text-white mb-4 text-center">
                  {language === "ar" ? "ماذا تريد أن تضيف؟" : "What would you like to add?"}
                </h3>
                
                <div className="space-y-3">
                  {addOptions.map((option, index) => {
                    const IconComponent = option.icon;
                    return (
                      <motion.div
                        key={option.href}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                      >
                        <Button
                          variant="outline"
                          className="w-full p-4 h-auto hover:shadow-md transition-all group"
                          onClick={() => handleOptionClick(option.href)}
                        >
                          <div className="flex items-center space-x-3 w-full">
                            <div className={`w-10 h-10 ${option.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                              <IconComponent className="h-5 w-5 text-white" />
                            </div>
                            
                            <div className="flex-1 text-right">
                              <h4 className="font-medium text-gray-900 dark:text-white text-sm">
                                {language === "ar" ? option.title : option.titleEn}
                              </h4>
                              <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                                {language === "ar" ? option.description : option.descriptionEn}
                              </p>
                            </div>
                            
                            <ArrowRight className="h-4 w-4 text-gray-400 group-hover:text-primary transition-colors flex-shrink-0" />
                          </div>
                          
                          {option.featured && (
                            <div className="absolute top-2 right-2">
                              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                            </div>
                          )}
                        </Button>
                      </motion.div>
                    );
                  })}
                </div>

                {/* Quick Benefits */}
                <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                  <p className="text-xs text-gray-500 dark:text-gray-400 text-center mb-3">
                    {language === "ar" ? "لماذا تختارنا؟" : "Why choose us?"}
                  </p>
                  <div className="grid grid-cols-3 gap-2">
                    {benefits.map((benefit, index) => {
                      const IconComponent = benefit.icon;
                      return (
                        <div key={index} className="text-center">
                          <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-1">
                            <IconComponent className="h-4 w-4 text-primary" />
                          </div>
                          <p className="text-xs font-medium text-gray-900 dark:text-white">
                            {benefit.title}
                          </p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            {benefit.description}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Close Button */}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsExpanded(false)}
                  className="w-full mt-3 text-gray-500 hover:text-gray-700"
                >
                  {language === "ar" ? "إغلاق" : "Close"}
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Login Prompt Dialog */}
      <Dialog open={showLoginPrompt} onOpenChange={setShowLoginPrompt}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">
              {language === "ar" ? "تسجيل الدخول مطلوب" : "Login Required"}
            </DialogTitle>
          </DialogHeader>
          
          <div className="text-center py-4">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Car className="h-8 w-8 text-primary" />
            </div>
            
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
              {language === "ar" ? "انضم إلى سوق سوريا" : "Join Souq Syria"}
            </h3>
            
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              {language === "ar" 
                ? "سجل الدخول أو أنشئ حساباً جديداً لإضافة الإعلانات والاستفادة من جميع الميزات"
                : "Sign in or create a new account to add listings and access all features"
              }
            </p>

            {/* Benefits List */}
            <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 mb-6">
              <h4 className="font-medium text-gray-900 dark:text-white mb-3">
                {language === "ar" ? "مع الحساب يمكنك:" : "With an account you can:"}
              </h4>
              <div className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>{language === "ar" ? "إضافة إعلانات السيارات مجاناً" : "Add car listings for free"}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>{language === "ar" ? "محادثة مباشرة مع المشترين" : "Direct chat with buyers"}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>{language === "ar" ? "إدارة إعلاناتك بسهولة" : "Manage your listings easily"}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>{language === "ar" ? "حفظ السيارات المفضلة" : "Save favorite cars"}</span>
                </div>
              </div>
            </div>

            <div className="flex space-x-3">
              <Button asChild className="flex-1">
                <Link href="/auth/login">
                  {language === "ar" ? "تسجيل الدخول" : "Login"}
                </Link>
              </Button>
              <Button variant="outline" asChild className="flex-1">
                <Link href="/auth/register">
                  {language === "ar" ? "إنشاء حساب" : "Register"}
                </Link>
              </Button>
            </div>
            
            <Button
              variant="ghost"
              onClick={() => setShowLoginPrompt(false)}
              className="w-full mt-3"
            >
              {language === "ar" ? "إلغاء" : "Cancel"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Backdrop for mobile */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsExpanded(false)}
            className="fixed inset-0 bg-black/20 z-30 md:hidden"
          />
        )}
      </AnimatePresence>
    </>
  );
}
