import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/components/language-provider";
import { motion, AnimatePresence } from "framer-motion";
import { 
  MessageCircle, Send, Minimize2, X, User, 
  Clock, CheckCircle, Phone, Mail, Headphones,
  Bot, Smile, Paperclip, Star
} from "lucide-react";

interface ChatMessage {
  id: string;
  content: string;
  sender: 'user' | 'support' | 'bot';
  timestamp: Date;
  isRead?: boolean;
}

export default function ChatWidget() {
  const { user } = useAuth();
  const { language } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [supportAgent, setSupportAgent] = useState({
    name: "أحمد محمد",
    status: "online",
    avatar: "",
    responseTime: "يرد عادة خلال دقائق"
  });
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Initialize with welcome message
  useEffect(() => {
    const welcomeMessage: ChatMessage = {
      id: '1',
      content: language === "ar" 
        ? "مرحباً! كيف يمكنني مساعدتك اليوم؟" 
        : "Hello! How can I help you today?",
      sender: 'support',
      timestamp: new Date(),
      isRead: true
    };
    setMessages([welcomeMessage]);
  }, [language]);

  // Simulate typing indicator
  const showTypingIndicator = () => {
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      // Add bot response after typing
      addBotResponse();
    }, 1500);
  };

  const addBotResponse = () => {
    const responses = [
      "شكراً لك على تواصلك معنا. سيتم توجيهك لأحد ممثلي خدمة العملاء قريباً.",
      "هل تحتاج مساعدة في العثور على سيارة معينة؟",
      "يمكنك تصفح السيارات المتاحة أو إضافة إعلان جديد.",
      "فريق الدعم متاح 24/7 لمساعدتك."
    ];

    const randomResponse = responses[Math.floor(Math.random() * responses.length)];
    
    const botMessage: ChatMessage = {
      id: Date.now().toString(),
      content: randomResponse,
      sender: 'support',
      timestamp: new Date(),
      isRead: false
    };

    setMessages(prev => [...prev, botMessage]);
    
    if (!isOpen) {
      setUnreadCount(prev => prev + 1);
    }
  };

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      content: inputMessage,
      sender: 'user',
      timestamp: new Date(),
      isRead: true
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage("");
    
    // Simulate support response
    showTypingIndicator();
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const toggleWidget = () => {
    setIsOpen(!isOpen);
    setIsMinimized(false);
    if (!isOpen) {
      setUnreadCount(0); // Clear unread count when opening
    }
  };

  const quickActions = [
    { text: "أحتاج مساعدة في البحث", action: () => setInputMessage("أحتاج مساعدة في البحث عن سيارة") },
    { text: "مشكلة في الموقع", action: () => setInputMessage("أواجه مشكلة في استخدام الموقع") },
    { text: "أسئلة حول البيع", action: () => setInputMessage("لدي أسئلة حول بيع سيارتي") },
    { text: "شكوى", action: () => setInputMessage("أريد تقديم شكوى") }
  ];

  return (
    <>
      {/* Chat Widget Button */}
      <motion.div
        className="fixed bottom-6 right-6 z-50"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <Button
          onClick={toggleWidget}
          className="w-16 h-16 bg-green-500 hover:bg-green-600 text-white rounded-full shadow-lg relative"
          title="محادثة مباشرة"
        >
          <AnimatePresence mode="wait">
            {isOpen ? (
              <motion.div
                key="close"
                initial={{ rotate: -90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: 90, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <X className="h-6 w-6" />
              </motion.div>
            ) : (
              <motion.div
                key="chat"
                initial={{ rotate: 90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: -90, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <MessageCircle className="h-6 w-6" />
              </motion.div>
            )}
          </AnimatePresence>
          
          {/* Unread Messages Badge */}
          {unreadCount > 0 && !isOpen && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-6 h-6 flex items-center justify-center font-bold"
            >
              {unreadCount > 9 ? '9+' : unreadCount}
            </motion.div>
          )}
        </Button>
      </motion.div>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="fixed bottom-24 right-6 z-50 w-80 md:w-96"
          >
            <Card className="shadow-2xl border-0 overflow-hidden">
              {/* Header */}
              <CardHeader className="bg-green-500 text-white p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Avatar className="w-10 h-10 border-2 border-white">
                      <AvatarImage src={supportAgent.avatar} />
                      <AvatarFallback className="bg-green-600 text-white">
                        <Headphones className="h-5 w-5" />
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle className="text-lg text-white">
                        خدمة العملاء
                      </CardTitle>
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-green-200 rounded-full animate-pulse"></div>
                        <span className="text-sm text-green-100">
                          {supportAgent.status === 'online' ? 'متاح الآن' : 'غير متاح'}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setIsMinimized(!isMinimized)}
                      className="text-white hover:bg-green-600 w-8 h-8 p-0"
                    >
                      <Minimize2 className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setIsOpen(false)}
                      className="text-white hover:bg-green-600 w-8 h-8 p-0"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                {/* Support Agent Info */}
                <div className="text-xs text-green-100 mt-2">
                  {supportAgent.responseTime}
                </div>
              </CardHeader>

              {/* Chat Content */}
              <AnimatePresence>
                {!isMinimized && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <CardContent className="p-0">
                      {/* Messages */}
                      <ScrollArea className="h-80">
                        <div className="p-4 space-y-4">
                          {messages.map((message, index) => (
                            <motion.div
                              key={message.id}
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: index * 0.1 }}
                              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                            >
                              <div className={`max-w-xs px-4 py-2 rounded-2xl ${
                                message.sender === 'user'
                                  ? 'bg-green-500 text-white rounded-br-sm'
                                  : 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white rounded-bl-sm'
                              }`}>
                                <p className="text-sm">{message.content}</p>
                                <div className={`flex items-center justify-end space-x-1 mt-1 ${
                                  message.sender === 'user' ? 'text-green-100' : 'text-gray-500 dark:text-gray-400'
                                }`}>
                                  <span className="text-xs">
                                    {message.timestamp.toLocaleTimeString('ar-SY', {
                                      hour: '2-digit',
                                      minute: '2-digit'
                                    })}
                                  </span>
                                  {message.sender === 'user' && (
                                    <CheckCircle className="h-3 w-3" />
                                  )}
                                </div>
                              </div>
                            </motion.div>
                          ))}
                          
                          {/* Typing Indicator */}
                          {isTyping && (
                            <motion.div
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              className="flex justify-start"
                            >
                              <div className="bg-gray-100 dark:bg-gray-700 px-4 py-2 rounded-2xl rounded-bl-sm">
                                <div className="flex space-x-1">
                                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                                </div>
                              </div>
                            </motion.div>
                          )}
                          
                          <div ref={messagesEndRef} />
                        </div>
                      </ScrollArea>

                      {/* Quick Actions */}
                      {messages.length <= 1 && (
                        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
                          <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">
                            كيف يمكنني مساعدتك؟
                          </p>
                          <div className="grid grid-cols-1 gap-2">
                            {quickActions.map((action, index) => (
                              <Button
                                key={index}
                                variant="outline"
                                size="sm"
                                className="text-right justify-start text-xs h-8"
                                onClick={action.action}
                              >
                                {action.text}
                              </Button>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Message Input */}
                      <div className="p-4 border-t border-gray-200 dark:border-gray-700">
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-gray-400 hover:text-gray-600"
                          >
                            <Paperclip className="h-4 w-4" />
                          </Button>
                          
                          <div className="flex-1 relative">
                            <Input
                              placeholder="اكتب رسالة..."
                              value={inputMessage}
                              onChange={(e) => setInputMessage(e.target.value)}
                              onKeyPress={handleKeyPress}
                              className="pr-10"
                            />
                            <Button
                              variant="ghost"
                              size="sm"
                              className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                            >
                              <Smile className="h-4 w-4" />
                            </Button>
                          </div>
                          
                          <Button
                            onClick={handleSendMessage}
                            disabled={!inputMessage.trim()}
                            className="bg-green-500 hover:bg-green-600 text-white w-10 h-10 p-0"
                          >
                            <Send className="h-4 w-4" />
                          </Button>
                        </div>
                        
                        {!user && (
                          <p className="text-xs text-gray-500 dark:text-gray-400 mt-2 text-center">
                            <Button variant="link" className="text-xs p-0 h-auto">
                              سجل الدخول
                            </Button>{" "}
                            للحصول على دعم أفضل
                          </p>
                        )}
                      </div>

                      {/* Footer */}
                      <div className="px-4 py-2 bg-gray-50 dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700">
                        <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
                          <div className="flex items-center space-x-2">
                            <Star className="h-3 w-3 text-yellow-400 fill-current" />
                            <span>نقدر ملاحظاتك</span>
                          </div>
                          <div className="flex items-center space-x-3">
                            <Button variant="ghost" size="sm" className="text-xs h-6 p-1">
                              <Phone className="h-3 w-3 mr-1" />
                              اتصال
                            </Button>
                            <Button variant="ghost" size="sm" className="text-xs h-6 p-1">
                              <Mail className="h-3 w-3 mr-1" />
                              إيميل
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </motion.div>
                )}
              </AnimatePresence>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
