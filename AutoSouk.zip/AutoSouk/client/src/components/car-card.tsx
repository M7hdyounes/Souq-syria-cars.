import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Heart, MapPin, Eye, MessageCircle, Star } from "lucide-react";
import { Car } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/components/language-provider";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

interface CarCardProps {
  car: Car;
  showSellerInfo?: boolean;
  className?: string;
}

export default function CarCard({ car, showSellerInfo = true, className }: CarCardProps) {
  const { user } = useAuth();
  const { t, isRTL } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const favoriteMutation = useMutation({
    mutationFn: async (action: 'add' | 'remove') => {
      if (!user) throw new Error("يجب تسجيل الدخول أولاً");
      
      if (action === 'add') {
        return apiRequest("POST", "/api/favorites", { userId: user.id, carId: car.id });
      } else {
        return apiRequest("DELETE", "/api/favorites", { userId: user.id, carId: car.id });
      }
    },
    onSuccess: (_, action) => {
      queryClient.invalidateQueries({ queryKey: ['/api/cars'] });
      queryClient.invalidateQueries({ queryKey: ['/api/users', user?.id, 'favorites'] });
      
      toast({
        title: action === 'add' ? "تمت الإضافة" : "تم الحذف",
        description: action === 'add' 
          ? "تم إضافة السيارة إلى المفضلة" 
          : "تم حذف السيارة من المفضلة"
      });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ",
        description: error.message || "حدث خطأ أثناء العملية",
        variant: "destructive"
      });
    }
  });

  const handleFavoriteToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!user) {
      toast({
        title: "تسجيل الدخول مطلوب",
        description: "يجب تسجيل الدخول لإضافة السيارات للمفضلة",
        variant: "destructive"
      });
      return;
    }

    // This would need to be enhanced with actual favorite status checking
    favoriteMutation.mutate('add');
  };

  const formatPrice = (price: string) => {
    const numPrice = parseFloat(price);
    return new Intl.NumberFormat('ar-SY').format(numPrice);
  };

  const getMainImage = () => {
    if (car.images && Array.isArray(car.images) && car.images.length > 0) {
      return car.images[0];
    }
    return "https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600";
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={className}
    >
      <Card className="car-card group cursor-pointer">
        <div className="relative">
          <img 
            src={getMainImage()} 
            alt={car.title}
            className="w-full h-48 object-cover"
            loading="lazy"
          />
          
          {/* Overlay with view count */}
          <div className="absolute top-4 left-4 flex items-center space-x-1 bg-black/50 text-white px-2 py-1 rounded-lg text-xs">
            <Eye className="h-3 w-3" />
            <span>{car.viewCount || 0}</span>
          </div>

          {/* Favorite button */}
          <Button
            variant="ghost"
            size="sm"
            className="absolute top-4 right-4 p-2 rounded-full bg-white/80 hover:bg-white"
            onClick={handleFavoriteToggle}
            disabled={favoriteMutation.isPending}
          >
            <Heart className="h-4 w-4 text-gray-600 hover:text-red-500" />
          </Button>

          {/* Status badges */}
          <div className="absolute bottom-4 left-4 flex space-x-2">
            {car.isFeatured && (
              <Badge variant="default" className="bg-primary text-white">
                مميز
              </Badge>
            )}
            {car.negotiable && (
              <Badge variant="secondary">
                قابل للتفاوض
              </Badge>
            )}
          </div>
        </div>

        <CardContent className="p-6">
          <Link href={`/cars/${car.id}`}>
            <div className="space-y-3">
              {/* Title and specs */}
              <div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white group-hover:text-primary transition-colors">
                  {car.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-300 text-sm">
                  {car.year} • {car.transmission} • {car.mileage ? `${car.mileage.toLocaleString()} كم` : 'غير محدد'}
                </p>
              </div>

              {/* Price and location */}
              <div className="flex justify-between items-center">
                <div className="price-badge">
                  {formatPrice(car.price)} ل.س
                </div>
                <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                  <MapPin className="h-4 w-4 ml-1" />
                  <span>{car.city}</span>
                </div>
              </div>

              {/* Seller info */}
              {showSellerInfo && (
                <div className="flex justify-between items-center pt-3 border-t border-gray-100 dark:border-gray-700">
                  <div className="flex items-center space-x-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src="" />
                      <AvatarFallback className="text-xs">
                        {car.sellerId.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium text-gray-900 dark:text-white">
                        {car.dealershipId ? "معرض تجاري" : "مالك خاص"}
                      </p>
                      <div className="flex items-center">
                        <div className="seller-rating text-xs">
                          <Star className="h-3 w-3 fill-current" />
                          <Star className="h-3 w-3 fill-current" />
                          <Star className="h-3 w-3 fill-current" />
                          <Star className="h-3 w-3 fill-current" />
                          <Star className="h-3 w-3" />
                        </div>
                        <span className="text-xs text-gray-500 dark:text-gray-400 mr-1">
                          (4.5)
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        // Handle message action
                      }}
                    >
                      <MessageCircle className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}

              {/* Action button */}
              <Button className="w-full mt-4" asChild>
                <Link href={`/cars/${car.id}`}>
                  {t("btn.viewDetails")}
                </Link>
              </Button>
            </div>
          </Link>
        </CardContent>
      </Card>
    </motion.div>
  );
}
