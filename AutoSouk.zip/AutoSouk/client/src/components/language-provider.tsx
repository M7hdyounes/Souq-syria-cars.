import React, { createContext, useContext, useState, useEffect } from "react";

type Language = "ar" | "en";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  isRTL: boolean;
}

const translations = {
  ar: {
    // Navigation
    "nav.home": "الرئيسية",
    "nav.cars": "تصفح السيارات",
    "nav.dealerships": "المعارض",
    "nav.contact": "اتصل بنا",
    "nav.login": "تسجيل الدخول",
    "nav.register": "إنشاء حساب",
    "nav.profile": "الملف الشخصي",
    "nav.messages": "الرسائل",
    "nav.favorites": "المفضلة",
    "nav.logout": "تسجيل الخروج",
    
    // Home page
    "home.hero.title": "أكبر سوق للسيارات في سوريا",
    "home.hero.subtitle": "اكتشف، اشتري، وبع السيارات بكل سهولة وأمان",
    "home.search.type": "نوع السيارة",
    "home.search.brand": "الماركة",
    "home.search.city": "المحافظة",
    "home.search.button": "بحث",
    "home.stats.cars": "سيارة معروضة",
    "home.stats.dealers": "معرض ومتجر",
    "home.stats.users": "مستخدم نشط",
    "home.featured.title": "السيارات المميزة",
    "home.featured.subtitle": "تصفح أفضل العروض والسيارات المختارة بعناية من أوثق المعارض في سوريا",
    "home.categories.title": "تصفح حسب النوع",
    "home.categories.subtitle": "اختر نوع السيارة المناسب لاحتياجاتك",
    "home.dealerships.title": "المعارض الموثوقة",
    "home.dealerships.subtitle": "تعامل مع أفضل المعارض المعتمدة في سوريا",
    "home.trust.title": "لماذا تختار سوق سوريا؟",
    "home.trust.subtitle": "نوفر لك أفضل تجربة في بيع وشراء السيارات بأمان وثقة",
    "home.cta.title": "هل تريد بيع سيارتك؟",
    "home.cta.subtitle": "انشر إعلانك مجاناً واحصل على أفضل العروض من المشترين",
    
    // Common
    "common.loading": "جاري التحميل...",
    "common.error": "حدث خطأ",
    "common.success": "تم بنجاح",
    "common.cancel": "إلغاء",
    "common.save": "حفظ",
    "common.delete": "حذف",
    "common.edit": "تعديل",
    "common.view": "عرض",
    "common.add": "إضافة",
    "common.search": "بحث",
    "common.filter": "تصفية",
    "common.sort": "ترتيب",
    "common.price": "السعر",
    "common.location": "الموقع",
    "common.date": "التاريخ",
    "common.rating": "التقييم",
    "common.reviews": "المراجعات",
    "common.contact": "تواصل",
    "common.share": "مشاركة",
    "common.favorite": "مفضلة",
    "common.compare": "مقارنة",
    "common.details": "التفاصيل",
    "common.photos": "الصور",
    "common.description": "الوصف",
    
    // Car related
    "car.brand": "الماركة",
    "car.model": "الموديل",
    "car.year": "السنة",
    "car.price": "السعر",
    "car.mileage": "المسافة المقطوعة",
    "car.fuel": "نوع الوقود",
    "car.transmission": "ناقل الحركة",
    "car.body": "نوع الهيكل",
    "car.color": "اللون",
    "car.condition": "الحالة",
    "car.features": "المواصفات",
    "car.negotiable": "قابل للتفاوض",
    "car.installments": "أقساط متاحة",
    "car.trade": "مقايضة مقبولة",
    
    // Buttons
    "btn.viewDetails": "عرض التفاصيل",
    "btn.addToFavorites": "إضافة للمفضلة",
    "btn.removeFromFavorites": "حذف من المفضلة",
    "btn.sendMessage": "إرسال رسالة",
    "btn.callSeller": "اتصال بالبائع",
    "btn.viewAllCars": "عرض جميع السيارات",
    "btn.addCar": "أضف سيارة",
    "btn.sellCar": "بيع سيارة",
    
    // Footer
    "footer.quickLinks": "روابط سريعة",
    "footer.support": "الدعم",
    "footer.followUs": "تابعنا",
    "footer.availableOn": "متوفر على",
    "footer.copyright": "© 2024 سوق سوريا للسيارات. جميع الحقوق محفوظة.",
  },
  en: {
    // Navigation
    "nav.home": "Home",
    "nav.cars": "Browse Cars",
    "nav.dealerships": "Dealerships",
    "nav.contact": "Contact Us",
    "nav.login": "Login",
    "nav.register": "Register",
    "nav.profile": "Profile",
    "nav.messages": "Messages",
    "nav.favorites": "Favorites",
    "nav.logout": "Logout",
    
    // Home page
    "home.hero.title": "Syria's Largest Car Marketplace",
    "home.hero.subtitle": "Discover, buy, and sell cars easily and safely",
    "home.search.type": "Car Type",
    "home.search.brand": "Brand",
    "home.search.city": "City",
    "home.search.button": "Search",
    "home.stats.cars": "Cars Listed",
    "home.stats.dealers": "Dealers & Showrooms",
    "home.stats.users": "Active Users",
    "home.featured.title": "Featured Cars",
    "home.featured.subtitle": "Browse the best deals and carefully selected cars from trusted dealers in Syria",
    "home.categories.title": "Browse by Type",
    "home.categories.subtitle": "Choose the right car type for your needs",
    "home.dealerships.title": "Trusted Dealerships",
    "home.dealerships.subtitle": "Deal with the best certified dealers in Syria",
    "home.trust.title": "Why Choose Souq Syria?",
    "home.trust.subtitle": "We provide you with the best experience in buying and selling cars safely and confidently",
    "home.cta.title": "Want to Sell Your Car?",
    "home.cta.subtitle": "Post your ad for free and get the best offers from buyers",
    
    // Common
    "common.loading": "Loading...",
    "common.error": "An error occurred",
    "common.success": "Success",
    "common.cancel": "Cancel",
    "common.save": "Save",
    "common.delete": "Delete",
    "common.edit": "Edit",
    "common.view": "View",
    "common.add": "Add",
    "common.search": "Search",
    "common.filter": "Filter",
    "common.sort": "Sort",
    "common.price": "Price",
    "common.location": "Location",
    "common.date": "Date",
    "common.rating": "Rating",
    "common.reviews": "Reviews",
    "common.contact": "Contact",
    "common.share": "Share",
    "common.favorite": "Favorite",
    "common.compare": "Compare",
    "common.details": "Details",
    "common.photos": "Photos",
    "common.description": "Description",
    
    // Car related
    "car.brand": "Brand",
    "car.model": "Model",
    "car.year": "Year",
    "car.price": "Price",
    "car.mileage": "Mileage",
    "car.fuel": "Fuel Type",
    "car.transmission": "Transmission",
    "car.body": "Body Type",
    "car.color": "Color",
    "car.condition": "Condition",
    "car.features": "Features",
    "car.negotiable": "Negotiable",
    "car.installments": "Installments Available",
    "car.trade": "Trade-in Accepted",
    
    // Buttons
    "btn.viewDetails": "View Details",
    "btn.addToFavorites": "Add to Favorites",
    "btn.removeFromFavorites": "Remove from Favorites",
    "btn.sendMessage": "Send Message",
    "btn.callSeller": "Call Seller",
    "btn.viewAllCars": "View All Cars",
    "btn.addCar": "Add Car",
    "btn.sellCar": "Sell Car",
    
    // Footer
    "footer.quickLinks": "Quick Links",
    "footer.support": "Support",
    "footer.followUs": "Follow Us",
    "footer.availableOn": "Available On",
    "footer.copyright": "© 2024 Souq Syria Cars. All rights reserved.",
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => {
    const stored = localStorage.getItem("language") as Language;
    return stored || "ar";
  });

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
    localStorage.setItem("language", language);
  }, [language]);

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations[Language]] || key;
  };

  return (
    <LanguageContext.Provider value={{
      language,
      setLanguage,
      t,
      isRTL: language === "ar"
    }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
