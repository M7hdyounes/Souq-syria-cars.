import { Link } from "wouter";
import { useLanguage } from "@/components/language-provider";
import { Car, Facebook, MessageCircle, Phone, Instagram } from "lucide-react";
import { SOCIAL_MEDIA_LINKS, CONTACT_INFO } from "@/lib/constants";

export default function Footer() {
  const { language, t, isRTL } = useLanguage();

  const quickLinks = [
    { href: "/cars", label: t("nav.cars") },
    { href: "/add-car", label: t("btn.addCar") },
    { href: "/dealerships", label: t("nav.dealerships") },
    { href: "/how-to-sell", label: "كيفية البيع" },
    { href: "/pricing", label: "الأسعار" },
  ];

  const supportLinks = [
    { href: "/contact", label: t("nav.contact") },
    { href: "/faq", label: "الأسئلة الشائعة" },
    { href: "/privacy", label: "سياسة الخصوصية" },
    { href: "/terms", label: "شروط الاستخدام" },
    { href: "/complaints", label: "تقديم شكوى" },
  ];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="col-span-1 md:col-span-2">
            <div className={`flex items-center space-x-3 ${isRTL ? 'space-x-reverse' : ''} mb-4`}>
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Car className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold">
                  {language === "ar" ? "سوق سوريا للسيارات" : "Souq Syria Cars"}
                </h3>
                <p className="text-sm text-gray-400">
                  {language === "ar" ? "Souq Syria Cars" : "سوق سوريا للسيارات"}
                </p>
              </div>
            </div>
            <p className="text-gray-400 mb-6 max-w-md">
              {language === "ar" 
                ? "أكبر منصة لبيع وشراء السيارات في سوريا. نربط البائعين والمشترين في بيئة آمنة وموثوقة."
                : "Syria's largest platform for buying and selling cars. We connect sellers and buyers in a safe and trusted environment."
              }
            </p>
            
            {/* Contact Info */}
            <div className="space-y-2 mb-6">
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4 text-primary" />
                <span className="text-sm text-gray-400">{CONTACT_INFO.phone}</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="h-4 w-4 text-primary">@</span>
                <span className="text-sm text-gray-400">{CONTACT_INFO.email}</span>
              </div>
            </div>

            {/* Social Media */}
            <div className={`flex space-x-4 ${isRTL ? 'space-x-reverse' : ''}`}>
              <a
                href={SOCIAL_MEDIA_LINKS.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-primary transition-colors"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href={SOCIAL_MEDIA_LINKS.telegram}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-primary transition-colors"
              >
                <MessageCircle className="h-5 w-5" />
              </a>
              <a
                href={SOCIAL_MEDIA_LINKS.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-primary transition-colors"
              >
                <Phone className="h-5 w-5" />
              </a>
              <a
                href={SOCIAL_MEDIA_LINKS.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-primary transition-colors"
              >
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">{t("footer.quickLinks")}</h4>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-gray-400 hover:text-white transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="text-lg font-semibold mb-4">{t("footer.support")}</h4>
            <ul className="space-y-2">
              {supportLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-gray-400 hover:text-white transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-800 pt-8 mt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              {t("footer.copyright")}
            </p>
            <div className={`flex items-center space-x-6 ${isRTL ? 'space-x-reverse' : ''} mt-4 md:mt-0`}>
              <span className="text-gray-400 text-sm">{t("footer.availableOn")}:</span>
              <div className={`flex space-x-3 ${isRTL ? 'space-x-reverse' : ''}`}>
                <a
                  href="#"
                  className="hover:text-white transition-colors"
                  title="iOS App"
                >
                  <span className="text-xl">🍎</span>
                </a>
                <a
                  href="#"
                  className="hover:text-white transition-colors"
                  title="Android App"
                >
                  <span className="text-xl">🤖</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
