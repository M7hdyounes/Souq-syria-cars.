import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useLanguage } from "@/components/language-provider";
import { motion } from "framer-motion";
import { Search, Filter, X, RotateCcw, MapPin, DollarSign, Calendar, Fuel, Settings } from "lucide-react";
import { 
  CAR_BRANDS, CAR_BODY_TYPES, SYRIAN_CITIES, FUEL_TYPES, 
  TRANSMISSION_TYPES, CAR_CONDITIONS 
} from "@/lib/constants";

interface SearchFiltersProps {
  onFiltersChange: (filters: any) => void;
  initialFilters?: any;
  showTitle?: boolean;
  compact?: boolean;
}

export default function SearchFilters({ 
  onFiltersChange, 
  initialFilters = {}, 
  showTitle = true,
  compact = false 
}: SearchFiltersProps) {
  const { language } = useLanguage();
  const [filters, setFilters] = useState({
    search: "",
    brand: "",
    model: "",
    bodyType: "",
    city: "",
    fuelType: "",
    transmission: "",
    condition: "",
    minPrice: [0],
    maxPrice: [100000000],
    minYear: [2000],
    maxYear: [2024],
    minMileage: [0],
    maxMileage: [500000],
    negotiable: false,
    installmentAvailable: false,
    tradeInAccepted: false,
    newCars: false,
    featuredOnly: false,
    ...initialFilters
  });

  const updateFilters = (newFilters: Partial<typeof filters>) => {
    const updatedFilters = { ...filters, ...newFilters };
    setFilters(updatedFilters);
    onFiltersChange(updatedFilters);
  };

  const clearFilters = () => {
    const defaultFilters = {
      search: "",
      brand: "",
      model: "",
      bodyType: "",
      city: "",
      fuelType: "",
      transmission: "",
      condition: "",
      minPrice: [0],
      maxPrice: [100000000],
      minYear: [2000],
      maxYear: [2024],
      minMileage: [0],
      maxMileage: [500000],
      negotiable: false,
      installmentAvailable: false,
      tradeInAccepted: false,
      newCars: false,
      featuredOnly: false,
    };
    setFilters(defaultFilters);
    onFiltersChange(defaultFilters);
  };

  const getActiveFiltersCount = () => {
    let count = 0;
    Object.entries(filters).forEach(([key, value]) => {
      if (key === 'search' && value) count++;
      else if (typeof value === 'string' && value) count++;
      else if (typeof value === 'boolean' && value) count++;
      else if (Array.isArray(value)) {
        if (key === 'minPrice' && value[0] > 0) count++;
        else if (key === 'maxPrice' && value[0] < 100000000) count++;
        else if (key === 'minYear' && value[0] > 2000) count++;
        else if (key === 'maxYear' && value[0] < 2024) count++;
        else if (key === 'minMileage' && value[0] > 0) count++;
        else if (key === 'maxMileage' && value[0] < 500000) count++;
      }
    });
    return count;
  };

  const formatPrice = (price: number) => {
    if (price >= 1000000) {
      return `${(price / 1000000).toFixed(1)}م`;
    }
    return price.toLocaleString();
  };

  if (compact) {
    return (
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Quick Search */}
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="ابحث عن سيارة..."
                value={filters.search}
                onChange={(e) => updateFilters({ search: e.target.value })}
                className="pl-10"
              />
            </div>

            {/* Brand */}
            <Select value={filters.brand} onValueChange={(value) => updateFilters({ brand: value })}>
              <SelectTrigger>
                <SelectValue placeholder="الماركة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">جميع الماركات</SelectItem>
                {CAR_BRANDS.map(brand => (
                  <SelectItem key={brand} value={brand}>{brand}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Body Type */}
            <Select value={filters.bodyType} onValueChange={(value) => updateFilters({ bodyType: value })}>
              <SelectTrigger>
                <SelectValue placeholder="نوع الهيكل" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">جميع الأنواع</SelectItem>
                {CAR_BODY_TYPES.map(type => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* City */}
            <Select value={filters.city} onValueChange={(value) => updateFilters({ city: value })}>
              <SelectTrigger>
                <SelectValue placeholder="المدينة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">جميع المدن</SelectItem>
                {SYRIAN_CITIES.map(city => (
                  <SelectItem key={city} value={city}>{city}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {getActiveFiltersCount() > 0 && (
            <div className="flex items-center justify-between mt-4 pt-4 border-t">
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">الفلاتر النشطة:</span>
                <Badge variant="secondary">
                  {getActiveFiltersCount()}
                </Badge>
              </div>
              <Button variant="ghost" size="sm" onClick={clearFilters}>
                <RotateCcw className="h-4 w-4 mr-2" />
                إعادة تعيين
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      {showTitle && (
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Filter className="h-5 w-5" />
              <span>فلاتر البحث</span>
            </div>
            {getActiveFiltersCount() > 0 && (
              <div className="flex items-center space-x-2">
                <Badge variant="default">
                  {getActiveFiltersCount()} فلتر نشط
                </Badge>
                <Button variant="ghost" size="sm" onClick={clearFilters}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            )}
          </CardTitle>
        </CardHeader>
      )}
      
      <CardContent className="space-y-6">
        {/* Search */}
        <div>
          <Label className="text-sm font-medium mb-2 block">
            البحث
          </Label>
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="ابحث عن سيارة، ماركة، موديل..."
              value={filters.search}
              onChange={(e) => updateFilters({ search: e.target.value })}
              className="pl-10"
            />
          </div>
        </div>

        <Separator />

        {/* Car Details */}
        <div className="space-y-4">
          <h4 className="font-medium text-gray-900 dark:text-white flex items-center">
            <Settings className="h-4 w-4 mr-2" />
            تفاصيل السيارة
          </h4>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Brand */}
            <div>
              <Label className="text-sm font-medium mb-2 block">الماركة</Label>
              <Select value={filters.brand} onValueChange={(value) => updateFilters({ brand: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر الماركة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">جميع الماركات</SelectItem>
                  {CAR_BRANDS.map(brand => (
                    <SelectItem key={brand} value={brand}>{brand}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Model */}
            <div>
              <Label className="text-sm font-medium mb-2 block">الموديل</Label>
              <Input
                placeholder="مثال: كامري، أكورد"
                value={filters.model}
                onChange={(e) => updateFilters({ model: e.target.value })}
              />
            </div>

            {/* Body Type */}
            <div>
              <Label className="text-sm font-medium mb-2 block">نوع الهيكل</Label>
              <Select value={filters.bodyType} onValueChange={(value) => updateFilters({ bodyType: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر النوع" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">جميع الأنواع</SelectItem>
                  {CAR_BODY_TYPES.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Condition */}
            <div>
              <Label className="text-sm font-medium mb-2 block">الحالة</Label>
              <Select value={filters.condition} onValueChange={(value) => updateFilters({ condition: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر الحالة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">جميع الحالات</SelectItem>
                  {CAR_CONDITIONS.map(condition => (
                    <SelectItem key={condition} value={condition}>{condition}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Fuel Type */}
            <div>
              <Label className="text-sm font-medium mb-2 block">نوع الوقود</Label>
              <Select value={filters.fuelType} onValueChange={(value) => updateFilters({ fuelType: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="نوع الوقود" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">جميع الأنواع</SelectItem>
                  {FUEL_TYPES.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Transmission */}
            <div>
              <Label className="text-sm font-medium mb-2 block">ناقل الحركة</Label>
              <Select value={filters.transmission} onValueChange={(value) => updateFilters({ transmission: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="ناقل الحركة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">جميع الأنواع</SelectItem>
                  {TRANSMISSION_TYPES.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <Separator />

        {/* Price Range */}
        <div className="space-y-4">
          <h4 className="font-medium text-gray-900 dark:text-white flex items-center">
            <DollarSign className="h-4 w-4 mr-2" />
            نطاق السعر (ل.س)
          </h4>
          
          <div className="space-y-4">
            <div>
              <Label className="text-xs text-gray-500 mb-2 block">
                الحد الأدنى: {formatPrice(filters.minPrice[0])} ل.س
              </Label>
              <Slider
                value={filters.minPrice}
                onValueChange={(value) => updateFilters({ minPrice: value })}
                max={50000000}
                step={1000000}
                className="mt-2"
              />
            </div>
            <div>
              <Label className="text-xs text-gray-500 mb-2 block">
                الحد الأقصى: {formatPrice(filters.maxPrice[0])} ل.س
              </Label>
              <Slider
                value={filters.maxPrice}
                onValueChange={(value) => updateFilters({ maxPrice: value })}
                max={100000000}
                step={1000000}
                className="mt-2"
              />
            </div>
          </div>
        </div>

        <Separator />

        {/* Year Range */}
        <div className="space-y-4">
          <h4 className="font-medium text-gray-900 dark:text-white flex items-center">
            <Calendar className="h-4 w-4 mr-2" />
            سنة الصنع
          </h4>
          
          <div className="space-y-4">
            <div>
              <Label className="text-xs text-gray-500 mb-2 block">
                من: {filters.minYear[0]}
              </Label>
              <Slider
                value={filters.minYear}
                onValueChange={(value) => updateFilters({ minYear: value })}
                min={2000}
                max={2024}
                step={1}
                className="mt-2"
              />
            </div>
            <div>
              <Label className="text-xs text-gray-500 mb-2 block">
                إلى: {filters.maxYear[0]}
              </Label>
              <Slider
                value={filters.maxYear}
                onValueChange={(value) => updateFilters({ maxYear: value })}
                min={2000}
                max={2024}
                step={1}
                className="mt-2"
              />
            </div>
          </div>
        </div>

        <Separator />

        {/* Location */}
        <div>
          <Label className="text-sm font-medium mb-2 block flex items-center">
            <MapPin className="h-4 w-4 mr-2" />
            الموقع
          </Label>
          <Select value={filters.city} onValueChange={(value) => updateFilters({ city: value })}>
            <SelectTrigger>
              <SelectValue placeholder="اختر المدينة" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">جميع المدن</SelectItem>
              {SYRIAN_CITIES.map(city => (
                <SelectItem key={city} value={city}>{city}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Separator />

        {/* Additional Options */}
        <div className="space-y-4">
          <h4 className="font-medium text-gray-900 dark:text-white">
            خيارات إضافية
          </h4>
          
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="negotiable"
                checked={filters.negotiable}
                onCheckedChange={(checked) => updateFilters({ negotiable: !!checked })}
              />
              <Label htmlFor="negotiable" className="text-sm">
                قابل للتفاوض
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="installment"
                checked={filters.installmentAvailable}
                onCheckedChange={(checked) => updateFilters({ installmentAvailable: !!checked })}
              />
              <Label htmlFor="installment" className="text-sm">
                أقساط متاحة
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="tradein"
                checked={filters.tradeInAccepted}
                onCheckedChange={(checked) => updateFilters({ tradeInAccepted: !!checked })}
              />
              <Label htmlFor="tradein" className="text-sm">
                مقايضة مقبولة
              </Label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="newCars"
                checked={filters.newCars}
                onCheckedChange={(checked) => updateFilters({ newCars: !!checked })}
              />
              <Label htmlFor="newCars" className="text-sm">
                سيارات جديدة فقط
              </Label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="featured"
                checked={filters.featuredOnly}
                onCheckedChange={(checked) => updateFilters({ featuredOnly: !!checked })}
              />
              <Label htmlFor="featured" className="text-sm">
                السيارات المميزة فقط
              </Label>
            </div>
          </div>
        </div>

        {getActiveFiltersCount() > 0 && (
          <>
            <Separator />
            <Button variant="outline" onClick={clearFilters} className="w-full">
              <RotateCcw className="h-4 w-4 mr-2" />
              إعادة تعيين جميع الفلاتر
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  );
}
