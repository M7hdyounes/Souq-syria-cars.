# Syrian Car Marketplace - replit.md

## Overview

This is a full-stack car marketplace application designed specifically for the Syrian market. The platform enables users to buy, sell, and browse cars, while also supporting dealerships and providing real-time chat functionality. The application is built with modern web technologies and includes comprehensive multilingual support (Arabic/English) with RTL layout support.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (v5) for server state and caching
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom automotive theme colors and dark mode support
- **Animations**: Framer Motion for smooth interactions
- **Form Handling**: React Hook Form with Zod validation
- **Internationalization**: Custom language provider with Arabic/English support and RTL layouts

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Real-time Communication**: WebSocket server for instant messaging
- **Session Management**: PostgreSQL-based session store
- **Email Service**: SendGrid for notifications
- **Build System**: Vite for frontend, esbuild for backend

### Project Structure
- `client/` - React frontend application
- `server/` - Express.js backend API
- `shared/` - Shared TypeScript schemas and types
- `migrations/` - Database migration files

## Key Components

### Authentication System
- JWT-based authentication with localStorage persistence
- Dual authentication for regular users and admin users
- Email verification and password recovery support
- Phone number verification capabilities

### Car Management
- Comprehensive car listing system with detailed specifications
- Image upload and management for car photos
- Advanced filtering and search capabilities
- Price negotiation and installment options
- Car condition tracking and technical reports

### Dealership System
- Dealership registration and verification
- Subscription-based plans (free/premium)
- Rating and review system
- Featured dealership promotions

### Real-time Chat
- WebSocket-based instant messaging
- User presence indicators
- Message read receipts
- File attachment support
- Chat history persistence

### Multilingual Support
- Complete Arabic/English localization
- RTL (Right-to-Left) layout support for Arabic
- Dynamic language switching
- Culturally appropriate UI components

## Data Flow

### User Registration/Authentication
1. User submits registration form with email/phone
2. Server validates data and creates user record
3. Email verification sent via SendGrid
4. Upon verification, user gains full access
5. JWT token stored in localStorage for session persistence

### Car Listing Process
1. Authenticated user accesses add-car form
2. Multi-step form collects car details and images
3. Form validation using Zod schemas
4. Data submitted to server via API
5. Images processed and stored
6. Listing appears in search results immediately

### Real-time Messaging
1. WebSocket connection established on user login
2. Messages sent through WebSocket connection
3. Server persists messages to database
4. Real-time delivery to online recipients
5. Offline message queuing for later delivery

### Search and Filtering
1. Frontend sends filter parameters to API
2. Server constructs optimized database queries
3. Results returned with pagination
4. Client-side caching via TanStack Query
5. Real-time updates for new listings

## External Dependencies

### Core Framework Dependencies
- React ecosystem (React, React DOM, React Hook Form)
- TanStack Query for data fetching and caching
- Wouter for lightweight routing
- Framer Motion for animations

### UI and Styling
- Radix UI primitives for accessible components
- Tailwind CSS for utility-first styling
- Lucide React for consistent iconography
- Class Variance Authority for component variants

### Backend Services
- Neon Database for PostgreSQL hosting
- SendGrid for email delivery
- Drizzle ORM for type-safe database operations

### Development Tools
- TypeScript for type safety
- Vite for fast development and building
- ESBuild for backend bundling
- PostCSS for CSS processing

## Deployment Strategy

### Development Environment
- Vite dev server with HMR for frontend
- TSX for backend development with hot reload
- PostgreSQL database via Neon's serverless platform
- WebSocket server integrated with Express

### Production Build
1. Frontend built with Vite to static assets
2. Backend compiled with ESBuild to single bundle
3. Environment variables for database and email service
4. Static assets served from Express server

### Database Management
- Drizzle Kit for schema migrations
- PostgreSQL connection pooling
- Environment-based configuration
- Automated schema synchronization

### Key Features for Syrian Market
- Arabic language prioritization with proper RTL support
- Syrian city and region filtering
- Local phone number format validation
- Cultural considerations in UI/UX design
- Support for Syrian Pound (SYP) currency
- WhatsApp integration for communication preferences